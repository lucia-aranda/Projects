import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:onlinebooks_flutter/constants/custom_appbar.dart';
import 'package:onlinebooks_flutter/constants/custom_drawer.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ListaGeneros extends StatefulWidget {
  const ListaGeneros({super.key});
  @override
  State<ListaGeneros> createState() => _ListaGenerosState();
}

class _ListaGenerosState extends State<ListaGeneros> {
  final supabase = Supabase.instance.client;
  bool cargando = true;
  List<Map<String, dynamic>> generos = [];

  @override
  void initState() {
    super.initState();
    cargarGeneros();
  }

  cargarGeneros() async {
    setState(() {
      cargando = true;
    });
    try {
      final response = await supabase.from('genero').select();
      print(response);
      setState(() {
        generos = List<Map<String, dynamic>>.from(response);
      });
    } catch (e) {
      print(e);
      Get.snackbar(
        icon: Icon(Icons.error),
        'Error',
        'No se pudieron cargar los géneros',
        colorText: Colors.black,
      );
    } finally {
      setState(() {
        cargando = false;
      });
    }
  }

  Future<void> editarGenero(Map<String, dynamic> genero) async {
  final nombreController = TextEditingController(text: genero['nombre_genero']);
  final estatusController = TextEditingController(text: genero['estatus_genero'].toString());
  print(genero['pk_genero']);
  final id = genero['pk_genero'];

  return showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Editar Género'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            TextField(
              controller: nombreController,
              decoration: InputDecoration(labelText: 'Nombre del Género'),
            ),
            TextField(
              controller: estatusController,
              decoration: InputDecoration(labelText: 'Estatus'),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: <Widget>[
          TextButton(
            child: Text('Cancelar'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          ElevatedButton(
            child: Text('Guardar'),
            onPressed: () async {
              final updatedGenero = {
                'nombre_genero': nombreController.text,
                'estatus_genero': int.tryParse(estatusController.text) ?? 0, // Valor predeterminado en caso de error
              };

              print( updatedGenero );

              try {
                print(id);
                await supabase
                    .from('genero')
                    .update(updatedGenero)
                    .eq('pk_genero', id);


                cargarGeneros();
                Navigator.of(context).pop();
                Get.snackbar(
                  'Éxito',
                  'Género actualizado correctamente',
                  colorText: Colors.black,
                );
              } catch (e) {
                print(e);
                Get.snackbar(
                  icon: Icon(Icons.error),
                  'Error',
                  'No se pudo actualizar el género',
                  colorText: Colors.black,
                );
              }
            },
          ),
        ],
      );
    },
  );
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(
        appbarColor: Color.fromRGBO(17, 16, 29, 1),
      ),
      drawer: CustomDrawer(),
      body: cargando
          ? Center(child: CircularProgressIndicator())
          : generos.isEmpty
              ? Center(child: Text('No hay géneros disponibles'))
              : Center(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      columnSpacing: 20,
                      headingRowColor:
                          MaterialStateColor.resolveWith((states) => Color.fromRGBO(17, 16, 29, 1)),
                      headingTextStyle: TextStyle(color: Colors.white),
                      dataRowColor: MaterialStateColor.resolveWith((states) => Color.fromRGBO(228, 233, 247, 1)),
                      dataTextStyle: TextStyle(color: Colors.black),
                      columns: const <DataColumn>[
                        DataColumn(label: Text('Nombre del Género')),
                        DataColumn(label: Text('Estatus')),
                        DataColumn(label: Text('Acciones')),
                      ],
                      rows: generos
                          .map((genero) => DataRow(
                                cells: [
                                  DataCell(Text(genero['nombre_genero'])),
                                  DataCell(Text(genero['estatus_genero'].toString())),
                                  DataCell(ElevatedButton(
                                    onPressed: () => editarGenero(genero),
                                    child: Text('Editar'),
                                  )),
                                ],
                              ))
                          .toList(),
                    ),
                  ),
                ),
    );
  }
}