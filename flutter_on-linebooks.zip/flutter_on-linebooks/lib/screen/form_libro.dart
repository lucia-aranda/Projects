import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:get/get.dart';
import 'package:onlinebooks_flutter/constants/custom_appbar.dart';
import 'package:onlinebooks_flutter/constants/custom_drawer.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:io';
import 'dart:typed_data';

class FormLibro extends StatefulWidget {
  const FormLibro({super.key});

  @override
  State<FormLibro> createState() => _FormLibroState();
}

bool kIsWeb = bool.fromEnvironment('dart.library.js_util');

class _FormLibroState extends State<FormLibro> {
  final formulario_key = GlobalKey<FormState>();
  final titulo_controller = TextEditingController();
  final descripcion_controller = TextEditingController();
  final anio_publicacion_controller = TextEditingController();
  List generos = [];
  var pkGenero;
  List autores = [];
  var pkAutor;
  final supabase = Supabase.instance.client;
  bool cargando = false;

  final ImagePicker picker = ImagePicker();
  String rutaImagen = '';
  String nombrePortada = '';
  List<int>? bytesDeImagen;
  String rutaPdf = '';
  String nombrePdf = '';
  List<int>? bytesDePdf;

  // Método para traer géneros
  traerGeneros() async {
    try {
      generos = await supabase.from('genero').select();
      setState(() {});
    } catch (e) {
      print(e);
      Get.snackbar('Error', 'Hubo un error al traer los géneros',
          colorText: Colors.black);
    }
  }

  // Método para traer autores
  traerAutores() async {
    try {
      autores = await supabase.from('autor').select();
      setState(() {});
    } catch (e) {
      print(e);
      Get.snackbar('Error', 'Hubo un error al traer los autores',
          colorText: Colors.black);
    }
  }

  @override
  void initState() {
    super.initState();
    traerGeneros();
    traerAutores();
  }

  // Método para elegir la portada
  elegirPortada() async {
    try {
      final XFile? foto = await picker.pickImage(source: ImageSource.gallery);

      if (foto == null) {
        print('No seleccionaste ninguna portada');
      } else {
        print('Seleccionaste una portada');
        print(foto.mimeType);
        print(foto.name);
        print(foto.path);

        rutaImagen = foto.path;
        nombrePortada = foto.name;
        bytesDeImagen = await foto.readAsBytes();
        setState(() {});
      }
    } catch (e) {
      print('Error al elegir una portada');
      print(e);
    }
  }

  // Método para guardar el libro
  guardarLibro() async {
    try {
      setState(() {
        cargando = true;
      });

      final ahorita = DateTime.now().microsecondsSinceEpoch.toString();
      nombrePortada = ahorita + ' ' + nombrePortada;

      if (bytesDeImagen != null) {
        Uint8List imagenFinal = Uint8List.fromList(bytesDeImagen!);
        await supabase.storage
            .from('portadas')
            .uploadBinary(nombrePortada, imagenFinal);
        print('Portada subida con éxito');

        String url_portada =
            await supabase.storage.from('portadas').getPublicUrl(nombrePortada);
        print('Url de la portada obtenida');

        await supabase.from('libro').insert({
          'titulo': titulo_controller.text,
          'descripcion': descripcion_controller.text,
          'anio_publicacion': int.parse(anio_publicacion_controller.text),
          'imagen_portada': url_portada,
          // 'pdf_ruta': pdfPath,
          'fk_autor': pkAutor,
          'fk_genero': pkGenero,
          'estatus_libro': 1,
        });

        Get.snackbar(
          icon: Icon(Icons.check),
          'Guardado',
          'Libro guardado',
          colorText: Colors.black,
        );

        setState(() {
          bytesDeImagen = null;
          rutaImagen = '';
        });
      }
    } catch (e) {
      print('Error al subir la portada');
      print(e);

      Get.snackbar(
        icon: Icon(Icons.error),
        'Error',
        'Libro no guardado',
        colorText: Colors.black,
      );
    } finally {
      setState(() {
        cargando = false;
      });

      titulo_controller.clear();
      descripcion_controller.clear();
      anio_publicacion_controller.clear();
    }
  }

  // Widget para seleccionar y mostrar archivos
  Widget archivos() {
    return Column(
      children: [
        ElevatedButton(
          onPressed: () {
            elegirPortada();
          },
          child: Text('Selecciona una portada'),
        ),
        mostrarPortada()
      ],
    );
  }

  // Widget para mostrar la portada seleccionada
  Widget mostrarPortada() {
    if (rutaImagen == '') {
      return Text('No has seleccionado una portada');
    } else {
      Widget img;
      if (kIsWeb) {
        print('Es web');
        img = Image.network(rutaImagen, width: 200, height: 200);
      } else {
        print('No es web');
        img = Image.file(File(rutaImagen), width: 200, height: 200);
      }

      return Column(
        children: [
          img,
          SizedBox(height: 30),
          ElevatedButton(
            onPressed: cargando
                ? null
                : () {
                    if (formulario_key.currentState!.validate()) {
                      guardarLibro();
                    }
                  },
            child: cargando
                ? CircularProgressIndicator(color: Colors.black)
                : Text('Guardar'),
          ),
        ],
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(appbarColor: Color.fromRGBO(17, 16, 29, 1)),
      drawer: CustomDrawer(),
      body: Form(
        key: formulario_key,
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextFormField(
                controller: titulo_controller,
                decoration: InputDecoration(
                    hintText: 'Ingresa el título del libro',
                    border: OutlineInputBorder()),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Completa este campo';
                  }
                  return null;
                },
              ),
              SizedBox(height: 5),
              TextFormField(
                controller: descripcion_controller,
                decoration: InputDecoration(
                    hintText: 'Ingresa la descripción del libro',
                    border: OutlineInputBorder()),
                maxLines: 5,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Completa este campo';
                  }
                  return null;
                },
              ),
              SizedBox(height: 5),
              TextFormField(
                controller: anio_publicacion_controller,
                decoration: InputDecoration(
                    hintText: 'Ingresa el año de publicación',
                    border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Completa este campo';
                  }
                  if (int.tryParse(value) == null) {
                    return 'Ingresa un año válido';
                  }
                  return null;
                },
              ),
              SizedBox(height: 5),
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelText: 'Autor',
                  border: OutlineInputBorder(),
                ),
                hint: Text('Seleccione un autor'),
                icon: Icon(Icons.arrow_drop_down),
                isExpanded: true,
                menuMaxHeight: 500,
                value: pkAutor,
                items: autores
                    .map((e) => DropdownMenuItem(
                          value: e['pk_autor'],
                          child: Text(e['nombre_autor']),
                        ))
                    .toList(),
                onChanged: (value) {
                  print(value);
                  setState(() {
                    pkAutor = value;
                  });
                },
              ),
              SizedBox(height: 5),
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelText: 'Género',
                  border: OutlineInputBorder(),
                ),
                hint: Text('Seleccione un género'),
                icon: Icon(Icons.arrow_drop_down),
                isExpanded: true,
                menuMaxHeight: 500,
                value: pkGenero,
                items: generos
                    .map((e) => DropdownMenuItem(
                          value: e['pk_genero'],
                          child: Text(e['nombre_genero']),
                        ))
                    .toList(),
                onChanged: (value) {
                  print(value);
                  setState(() {
                    pkGenero = value;
                  });
                },
              ),
              SizedBox(height: 10),
              archivos()
            ],
          ),
        ),
      ),
    );
  }
}
