import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:onlinebooks_flutter/constants/custom_appbar.dart';
import 'package:onlinebooks_flutter/constants/custom_drawer.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class FormAutor extends StatefulWidget {
  const FormAutor({super.key});
  @override
  State<FormAutor> createState() => _FormAutorState();
}

class _FormAutorState extends State<FormAutor> {
  final formulario_key = GlobalKey<FormState>();
  final nombre_autor_controller = TextEditingController();
  final supabase = Supabase.instance.client;
  bool cargando = false;

  guardarAutor() async {
    setState(() {
      cargando = true;
    });
    try {
      await supabase.from('autor').insert({
        'nombre_autor': nombre_autor_controller.text,
        'estatus_autor': 1,
      });

      Get.snackbar(
        icon: Icon(Icons.check),
        'Guardado',
        'Autor guardado',
        colorText: Colors.black,
      );
    } catch (e) {
      print(e);

      Get.snackbar(
        icon: Icon(Icons.error),
        'Error',
        'Autor no guardado',
        colorText: Colors.black,
      );
    } finally {
      setState(() {
        cargando = false;
      });

      nombre_autor_controller.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: CustomAppbar(
          appbarColor: Color.fromRGBO(17, 16, 29, 1),
        ),
        drawer: CustomDrawer(),
        body: Form(
            key: formulario_key,
            child: Column(
              children: [
                TextFormField(
                  controller: nombre_autor_controller,
                  minLines: 1,
                  maxLines: 1,
                  decoration:
                      InputDecoration(hintText: 'Ingresa el nombre del autor'),
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Completa este campo';
                    }
                    return null;
                  },
                ),
                SizedBox(
                  height: 10,
                ),
                ElevatedButton(
                    onPressed: cargando
                        ? null
                        : () {
                            if (formulario_key.currentState!.validate()) {
                              print('Todo bien');
                              guardarAutor();
                            } else {
                              print('Algo anda mal');
                            }
                          },
                    child: cargando
                        ? CircularProgressIndicator(
                            color: Colors.black,
                          )
                        : Text('Guardar'))
              ],
            )));
  }
}
