import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:onlinebooks_flutter/constants/custom_appbar.dart';
import 'package:onlinebooks_flutter/constants/custom_drawer.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ListaAutores extends StatefulWidget {
  const ListaAutores({super.key});
  @override
  State<ListaAutores> createState() => _ListaAutoresState();
}

class _ListaAutoresState extends State<ListaAutores> {
  final supabase = Supabase.instance.client;
  bool cargando = true;
  List<Map<String, dynamic>> autores = [];

  @override
  void initState() {
    super.initState();
    cargarAutores();
  }

  cargarAutores() async {
    setState(() {
      cargando = true;
    });
    try {
      final response = await supabase.from('autor').select();
      print(response);
      setState(() {
        autores = List<Map<String, dynamic>>.from(response);
      });
    } catch (e) {
      print(e);
      Get.snackbar(
        icon: Icon(Icons.error),
        'Error',
        'No se pudieron cargar los autores',
        colorText: Colors.black,
      );
    } finally {
      setState(() {
        cargando = false;
      });
    }
  }

  Future<void> editarAutor(Map<String, dynamic> autor) async {
    final nombreController = TextEditingController(text: autor['nombre_autor']);
    final estatusController = TextEditingController(text: autor['estatus_autor'].toString());
    final id = autor['pk_autor'];

    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Editar Autor'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: nombreController,
                decoration: InputDecoration(labelText: 'Nombre del Autor'),
              ),
              TextField(
                controller: estatusController,
                decoration: InputDecoration(labelText: 'Estatus'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancelar'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              child: Text('Guardar'),
              onPressed: () async {
                final updatedAutor = {
                  'nombre_autor': nombreController.text,
                  'estatus_autor': int.tryParse(estatusController.text) ?? 0, // Valor predeterminado en caso de error
                };

                try {
                  await supabase
                      .from('autor')
                      .update(updatedAutor)
                      .eq('pk_autor', id);

                  cargarAutores();
                  Navigator.of(context).pop();
                  Get.snackbar(
                    'Éxito',
                    'Autor actualizado correctamente',
                    colorText: Colors.black,
                  );
                } catch (e) {
                  print(e);
                  Get.snackbar(
                    icon: Icon(Icons.error),
                    'Error',
                    'No se pudo actualizar el autor',
                    colorText: Colors.black,
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(
        appbarColor: Color.fromRGBO(17, 16, 29, 1),
      ),
      drawer: CustomDrawer(),
      body: cargando
          ? Center(child: CircularProgressIndicator())
          : autores.isEmpty
              ? Center(child: Text('No hay autores disponibles'))
              : Center(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      columnSpacing: 20,
                      headingRowColor:
                          MaterialStateColor.resolveWith((states) => Color.fromRGBO(17, 16, 29, 1)),
                      headingTextStyle: TextStyle(color: Colors.white),
                      dataRowColor: MaterialStateColor.resolveWith((states) => Color.fromRGBO(228, 233, 247, 1)),
                      dataTextStyle: TextStyle(color: Colors.black),
                      columns: const <DataColumn>[
                        DataColumn(label: Text('Nombre del Autor')),
                        DataColumn(label: Text('Estatus')),
                        DataColumn(label: Text('Acciones')),
                      ],
                      rows: autores
                          .map((autor) => DataRow(
                                cells: [
                                  DataCell(Text(autor['nombre_autor'])),
                                  DataCell(Text(autor['estatus_autor'].toString())),
                                  DataCell(ElevatedButton(
                                    onPressed: () => editarAutor(autor),
                                    child: Text('Editar'),
                                  )),
                                ],
                              ))
                          .toList(),
                    ),
                  ),
                ),
    );
  }
}