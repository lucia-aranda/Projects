import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:onlinebooks_flutter/constants/custom_appbar.dart';
import 'package:onlinebooks_flutter/constants/custom_drawer.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ListaLibros extends StatefulWidget {
  const ListaLibros({super.key});
  @override
  State<ListaLibros> createState() => _ListaGenerosState(); 
}

class _ListaGenerosState extends State<ListaLibros> {
  final supabase = Supabase.instance.client;
  bool cargando = true;
  List<Map<String, dynamic>> libros = [];

  @override
  void initState() {
    super.initState();
    cargarLibros();
  }

  cargarLibros() async {
    setState(() {
      cargando = true;
    });
    try {
      final response = await supabase.from('libro').select();
      print(response);
      setState(() {
        libros = List<Map<String, dynamic>>.from(response);
      });
    } catch (e) {
      print(e);
      Get.snackbar(
        icon: Icon(Icons.error),
        'Error',
        'No se pudieron cargar los libros',
        colorText: Colors.black,
      );
    } finally {
      setState(() {
        cargando = false;
      });
    }
  }

  Future<void> editarLibro(Map<String, dynamic> libro) async {

  // Controllers para los campos de texto
  final tituloController = TextEditingController(text: libro['titulo']);
  final descripcionController = TextEditingController(text: libro['descripcion']);
  final anioPublicacionController = TextEditingController(text: libro['anio_publicacion'].toString());

  // Variables para almacenar los géneros y autores seleccionados
  List generos = libro['generos'];
  var pkGenero = libro['pk_genero'];
  List autores = libro['autores'];
  var pkAutor = libro['pk_autor'];

  print(libro['pk_libro']);
  final id = libro['pk_libro'];

  return showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Editar Libro'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            TextField(
              controller: tituloController,
              decoration: InputDecoration(labelText: 'Título del Libro'),
            ),
            TextField(
              controller: descripcionController,
              decoration: InputDecoration(labelText: 'Descripción'),
              maxLines: 5, // Opcional, para permitir texto multilínea
            ),
            TextField(
              controller: anioPublicacionController,
              decoration: InputDecoration(labelText: 'Año de Publicación'),
              keyboardType: TextInputType.number,
            ),
            DropdownButton(
              value: pkGenero,
              items: generos.map((genero) {
                return DropdownMenuItem(
                  value: genero['pk_genero'],
                  child: Text(genero['nombre_genero']),
                );
              }).toList(),
              onChanged: (value) {
                pkGenero = value;
              },
            ),
            DropdownButton(
              value: pkAutor,
              items: autores.map((autor) {
                return DropdownMenuItem(
                  value: autor['pk_autor'],
                  child: Text(autor['nombre_autor']),
                );
              }).toList(),
              onChanged: (value) {
                pkAutor = value;
              },
            ),
          ],
        ),
        actions: <Widget>[
          TextButton(
            child: Text('Cancelar'),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          ElevatedButton(
            child: Text('Guardar'),
            onPressed: () async {
              final updatedLibro = {
                'titulo': tituloController.text,
                'descripcion': descripcionController.text,
                'anio_publicacion': int.tryParse(anioPublicacionController.text) ?? 0, // Valor predeterminado en caso de error
                'pk_genero': pkGenero,
                'pk_autor': pkAutor,
              };

              print( updatedLibro );

              try {
                print(id);
                await supabase
                    .from('libro')
                    .update(updatedLibro)
                    .eq('pk_libro', id);


                cargarLibros();
                Navigator.of(context).pop();
                Get.snackbar(
                  'Éxito',
                  'Libro actualizado correctamente',
                  colorText: Colors.black,
                );
              } catch (e) {
                print(e);
                Get.snackbar(
                  icon: Icon(Icons.error),
                  'Error',
                  'No se pudo actualizar el libro',
                  colorText: Colors.black,
                );
              }
            },
          ),
        ],
      );
    },
  );
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(
        appbarColor: Color.fromRGBO(17, 16, 29, 1),
      ),
      drawer: CustomDrawer(),
      body: cargando
          ? Center(child: CircularProgressIndicator())
          : libros.isEmpty
              ? Center(child: Text('No hay libros disponibles'))
              : Center(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: DataTable(
                      columnSpacing: 20,
                      headingRowColor:
                          MaterialStateColor.resolveWith((states) => Color.fromRGBO(17, 16, 29, 1)),
                      headingTextStyle: TextStyle(color: Colors.white),
                      dataRowColor: MaterialStateColor.resolveWith((states) => Color.fromRGBO(228, 233, 247, 1)),
                      dataTextStyle: TextStyle(color: Colors.black),
                      columns: const <DataColumn>[
                        DataColumn(label: Text('Título del Libro')),
                        DataColumn(label: Text('Descripción')),
                        DataColumn(label: Text('Año de Publicación')),
                        DataColumn(label: Text('Género')),
                        DataColumn(label: Text('Autor')),
                        DataColumn(label: Text('Acciones')),
                      ],
                      rows: libros
                          .map((libro) => DataRow(
                                cells: [
                                  DataCell(Text(libro['titulo'])),
                                  DataCell(Text(libro['descripcion'])),
                                  DataCell(Text(libro['anio_publicacion'].toString())),
                                  DataCell(Text(libro['pk_genero'].toString())),
                                  DataCell(Text(libro['pk_autor'].toString())),
                                  DataCell(ElevatedButton(
                                    onPressed: () => editarLibro(libro),
                                    child: Text('Editar'),
                                  )),
                                ],
                              ))
                          .toList(),
                    ),
                  ),
                ),
    );
  }
}