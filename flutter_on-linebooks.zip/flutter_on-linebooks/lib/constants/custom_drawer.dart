import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Color.fromRGBO(17, 16, 29, 1),
      width: 304,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              height: 100.0,
              child: Center(
                child: Text(
                  'On-linebooks',
                  style: TextStyle(color: Colors.white, fontSize: 24),
                ),
              ),
            ),
            Divider(color: Color.fromARGB(255, 214, 214, 214)),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    ListTile(
                      leading: Icon(Icons.home, color: Colors.white),
                      title: Text('INICIO'),
                      textColor: Colors.white,
                      onTap: () {
                        Get.toNamed('/');
                      },
                    ),
                    ListTile(
                      leading:
                          Icon(Icons.format_align_center, color: Colors.white),
                      title: Text('AGREGAR LIBRO'),
                      textColor: Colors.white,
                      onTap: () {
                        Get.toNamed('/agregar_libro');
                      },
                    ),
                    ListTile(
                      leading:
                          Icon(Icons.format_align_center, color: Colors.white),
                      title: Text('LISTA DE LIBROS'),
                      textColor: Colors.white,
                      onTap: () {
                        Get.toNamed('/lista_libro');
                      },
                    ),
                    ListTile(
                      leading:
                          Icon(Icons.format_align_center, color: Colors.white),
                      title: Text('AGREGAR AUTOR'),
                      textColor: Colors.white,
                      onTap: () {
                        Get.toNamed('/agregar_autor');
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.list, color: Colors.white),
                      title: Text('LISTA DE AUTORES'),
                      textColor: Colors.white,
                      onTap: () {
                        // Get.toNamed('/autores_guardados');
                        Get.toNamed('/lista_autor');
                      },
                    ),
                    ListTile(
                      leading:
                          Icon(Icons.format_align_center, color: Colors.white),
                      title: Text('AGREGAR GÉNERO'),
                      textColor: Colors.white,
                      onTap: () {
                        Get.toNamed('/agregar_genero');
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.list, color: Colors.white),
                      title: Text('LISTA DE GÉNEROS'),
                      textColor: Colors.white,
                      onTap: () {
                        // Get.toNamed('/generos_guardados');
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
