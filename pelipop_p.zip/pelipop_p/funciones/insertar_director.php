<?php
include("../clases/Director.php");

$director=new Director();

$nom_director=$_POST['nom_director'];

$respuesta=$director->insertar($nom_director);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

?>