<?php 
include ("../clases/Director.php");
$director=new Director();
$pk_director=$_GET["pk_director"];

$resultado=$director->baja($pk_director);

if($resultado){

	echo "Guardado";
}else{
    echo "Error";
}


 ?>