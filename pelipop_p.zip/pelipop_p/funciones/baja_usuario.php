<?php 
include ("../clases/Usuario.php");
$usuario=new Usuario();
$pk_usuario=$_GET["pk_usuario"];

$resultado=$usuario->baja($pk_usuario);

if($resultado){

	echo "Guardado";
}else{
    echo "Error";
}


 ?>