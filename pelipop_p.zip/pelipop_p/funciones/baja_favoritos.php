<?php 
include ("../clases/Favoritos.php");
$favoritos=new Favoritos();
$pk_fav=$_GET["pk_fav"];

$resultado=$favoritos->baja($pk_fav);

if($resultado){

	echo "Guardado";
}else{
    echo "Error";
}


 ?>