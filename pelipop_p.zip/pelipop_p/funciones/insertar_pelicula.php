<?php
include("../clases/Pelicula.php");

$pelicula=new Pelicula();

$titulo=$_POST['titulo'];
$descripcion=$_POST['descripcion'];
$duracion=$_POST['duracion'];
$calificacion=$_POST['calificacion'];
$fech_lanzamiento=$_POST['fech_lanzamiento'];
$fk_genero=$_POST['fk_genero'];


$respuesta=$pelicula->insertar($titulo,$descripcion,$duracion,$calificacion,$fech_lanzamiento,$fk_genero);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

?>