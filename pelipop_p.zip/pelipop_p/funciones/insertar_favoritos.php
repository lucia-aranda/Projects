<?php
include("../clases/Favoritos.php");
session_start();

$favoritos=new Favoritos();

$fk_pelicula=$_POST['fk_pelicula'];
$fk_usuario=$_POST['fk_usuario'];

$respuesta=$favoritos->insertar($fk_pelicula,$fk_usuario);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

?>