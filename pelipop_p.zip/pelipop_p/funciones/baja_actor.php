<?php 
include ("../clases/Actor.php");
$actor=new Actor();
$pk_actor=$_GET['pk_actor'];

$resultado=$actor->baja($pk_actor);

if($resultado==true){

	echo "Guardado";
}else{
    echo "Error";
}


 ?>