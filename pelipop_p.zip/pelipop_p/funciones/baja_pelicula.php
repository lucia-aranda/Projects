<?php 
include ("../clases/Pelicula.php");
$pelicula=new Pelicula();
$pk_pelicula=$_GET["pk_pelicula"];

$resultado=$pelicula->baja($pk_pelicula);

if($resultado){

	echo "Guardado";
}else{
    echo "Error";
}


 ?>