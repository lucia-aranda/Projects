<?php 
include("../clases/Director.php");
$director=new Director();

$pk_director=$_POST['pk_director'];
$nom_director=$_POST['nom_director'];

$respuesta=$director->actualizar($pk_director,$nom_director);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

 ?>