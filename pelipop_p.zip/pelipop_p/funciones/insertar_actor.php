<?php
include("../clases/Actor.php");

$actor=new Actor();

$nom_actor=$_POST['nom_actor'];

$respuesta=$actor->insertar($nom_actor);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

?>