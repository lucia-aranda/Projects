<?php 
include ("../clases/Genero.php");
$genero=new Genero();
$pk_genero=$_GET["pk_genero"];

$resultado=$genero->baja($pk_genero);

if($resultado){

	echo "Guardado";
}else{
    echo "Error";
}


 ?>