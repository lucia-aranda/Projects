<?php 
include("../clases/Pelicula.php");
$pelicula=new Pelicula();

$pk_pelicula=$_POST['pk_pelicula'];
$titulo=$_POST["titulo"];
$descripcion=$_POST["descripcion"];
$duracion=$_POST["duracion"];
$calificacion=$_POST["calificacion"];
$fech_lanzamiento=$_POST["fech_lanzamiento"];
$fk_genero=$_POST["fk_genero"];

$respuesta=$pelicula->actualizar($pk_pelicula,$titulo,$descripcion,$duracion,$calificacion,$fech_lanzamiento,$fk_genero);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

 ?>