<?php 
include("../clases/Actor.php");
$actor=new Actor();

$pk_actor=$_POST['pk_actor'];
$nom_actor=$_POST["nom_actor"];

$respuesta=$actor->actualizar($pk_actor,$nom_actor);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

 ?>