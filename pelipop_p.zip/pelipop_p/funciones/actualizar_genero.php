<?php 
include("../clases/Genero.php");
$genero=new Genero();

$pk_genero=$_POST['pk_genero'];
$nom_genero=$_POST["nom_genero"];

$respuesta=$genero->actualizar($pk_genero,$nom_genero);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

 ?>