<?php
include("../clases/Genero.php");

$genero=new Genero();

$nom_genero=$_POST['nom_genero'];

$respuesta=$genero->insertar($nom_genero);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

?>