<?php 
include("../clases/Favoritos.php");
$favoritos=new Favoritos();

$pk_fav=$_POST['pk_fav'];
$fk_pelicula=$_POST["fk_pelicula"];
$fk_usuario=$_POST['fk_usuario'];

$respuesta=$favoritos->actualizar($pk_fav,$fk_pelicula,$fk_usuario);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

 ?>