<?php
include ("menu.php");
?>
<link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css"> <!-- carrusel -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> <!-- carrusel -->
  <script src="js/bootstrap.js"></script>
  <!-- icono pag -->
    <link href="img/pop.ico" rel="icon">

<style>
* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
<br><br>
<!-- imagenes -->
<div class="row">

  <div class="column">&nbsp &nbsp &nbsp &nbsp &nbsp
    <img src="img/M.jpg" style="width:80%">
     <h1 align="center">Morbius</h1>
  </div>
  <!-- heart -->
  <!-- heart -->
  <div class="column"> &nbsp &nbsp &nbsp &nbsp &nbsp
    <img src="img/S2.jpg" style="width:80%">
    <h1 align="center">Sonic 2</h1>
    <br>
  </div>

  <div class="column"> &nbsp &nbsp &nbsp &nbsp &nbsp
    <img src="img/B.jpg" style="width:80%">
    <h1 align="center">Batman</h1>
    <br>
  </div>

</div>
<!-- imagenes -->
<!-- carrusel -->
<br><br>
<h1 id="accion">&nbsp &nbsp Acción</h1>
<br>
<div class="main-carousel">
  <div class="cell"><img src="img/SS.jpg"></div>
  <div class="cell"><img src="img/AD.jpg"></div>
  <div class="cell"><img src="img/RYF.jpg"></div>
  <div class="cell"><img src="img/JW.jpg"></div>
  <div class="cell"><img src="img/L.jpg"></div>
  <div class="cell"><img src="img/MK.jpg"></div>
  <div class="cell"><img src="img/REWRC.jpg"></div>
  <div class="cell"><img src="img/LPPS.jpg"></div>
  <div class="cell"><img src="img/RBC.jpg"></div>
  <div class="cell"><img src="img/12HPS.jpg"></div>
</div>

<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
<script type="text/javascript">
    $('.main-carousel').flickity({
  // options
  cellAlign: 'left',
  wrapAround: true,
  freeScroll: true
});
</script><br>
<!-- carrusel -->
<!-- carrusel -->
<br><br>
<h1 id="ciencia_ficcion">&nbsp &nbsp Ciencia ficción</h1>
<br>
<div class="main-carousel">
  <div class="cell"><img src="img/ABA.jpg"></div>
  <div class="cell"><img src="img/DUNE.jpg"></div>
  <div class="cell"><img src="img/PA.jpg"></div>
  <div class="cell"><img src="img/FG.jpg"></div>
  <div class="cell"><img src="img/GVSK.jpg"></div>
  <div class="cell"><img src="img/GM.jpg"></div>
  <div class="cell"><img src="img/PG.jpg"></div>
  <div class="cell"><img src="img/RPO.jpg"></div>
  <div class="cell"><img src="img/SMNWH.jpg"></div>
  <div class="cell"><img src="img/VLTBC.jpg"></div>
</div>

<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
<script type="text/javascript">
    $('.main-carousel').flickity({
  // options
  cellAlign: 'left',
  wrapAround: true,
  freeScroll: true
});
</script><br>
<!-- carrusel -->
<!-- carrusel -->
<br><br>
<h1 id="fantasia">&nbsp &nbsp Fantasía</h1>
<br>
<div class="main-carousel">
  <div class="cell"><img src="img/HTTYD.jpg"></div>
  <div class="cell"><img src="img/LPC.jpg"></div>
  <div class="cell"><img src="img/HP.jpg"></div>
  <div class="cell"><img src="img/J.jpg"></div>
  <div class="cell"><img src="img/V.jpg"></div>
  <div class="cell"><img src="img/N.jpg"></div>
  <div class="cell"><img src="img/MVT.jpg"></div>
  <div class="cell"><img src="img/E.jpg"></div>
  <div class="cell"><img src="img/TH.jpg"></div>
  <div class="cell"><img src="img/TLOTR.jpg"></div>
</div>

<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
<script type="text/javascript">
    $('.main-carousel').flickity({
  // options
  cellAlign: 'left',
  wrapAround: true,
  freeScroll: true
});
</script><br>
<!-- carrusel -->
<!-- carrusel -->
<br><br>
<h1 id="terror">&nbsp &nbsp Terror<h1/>
<br>
<div class="main-carousel">
  <div class="cell"><img src="img/IT2.jpg"></div>
  <div class="cell"><img src="img/ANNB2.jpg"></div>
  <div class="cell"><img src="img/MON.jpg"></div>
  <div class="cell"><img src="img/CONJ.jpg"></div>
  <div class="cell"><img src="img/LLO.jpg"></div>
  <div class="cell"><img src="img/PDBLB.jpg"></div>
  <div class="cell"><img src="img/EEX.jpg"></div>
  <div class="cell"><img src="img/CLSA.jpg"></div>
  <div class="cell"><img src="img/HDM.jpg"></div>
  <div class="cell"><img src="img/BB.jpg"></div>
</div>

<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
<script type="text/javascript">
    $('.main-carousel').flickity({
  // options
  cellAlign: 'left',
  wrapAround: true,
  freeScroll: true
});
</script><br>
<!-- carrusel -->
<!-- carrusel -->
<h1 id="comedia">&nbsp &nbsp Comedia<h1/>
<br>
<div class="main-carousel">
  <div class="cell"><img src="img/HA.jpg"></div>
  <div class="cell"><img src="img/GDP.jpg"></div>
  <div class="cell"><img src="img/PDM.jpg"></div>
  <div class="cell"><img src="img/WC.jpg"></div>
  <div class="cell"><img src="img/CSLL.jpg"></div>
  <div class="cell"><img src="img/SCN2.jpg"></div>
  <div class="cell"><img src="img/T.jpg"></div>
  <div class="cell"><img src="img/QPA3.jpg"></div>
  <div class="cell"><img src="img/S.jpg"></div>
  <div class="cell"><img src="img/LWS.jpg"></div>
</div>

<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
<script type="text/javascript">
    $('.main-carousel').flickity({
  // options
  cellAlign: 'left',
  wrapAround: true,
  freeScroll: true
});
</script><br>
<!-- carrusel -->