<?php 
class Pelicula
{
  
  function __construct()
  {
    require_once("Conexion.php");
    $this->conexion = new Conexion();
  }

  function insertar($titulo,$descripcion,$duracion,$calificacion,$fech_lanzamiento,$fk_genero){
    $consulta="INSERT INTO peliculas (pk_pelicula,titulo,descripcion,duracion,calificacion,fech_lanzamiento,fk_genero,estatus) VALUES (null,'{$titulo}','{$descripcion}','{$duracion}','{$calificacion}','{$fech_lanzamiento}','{$fk_genero}', 1)";
       $resultado=$this->conexion ->query ($consulta);
       return $resultado;

  }
   function mostrar(){

    $consulta="SELECT * FROM  peliculas p INNER JOIN  genero g ON  p.fk_genero=g.pk_genero";
    $resultado=$this->conexion->query($consulta);
    return $resultado;  
  }
   function mostrarPorId($pk_pelicula){

    $consulta="SELECT * FROM peliculas where pk_pelicula ='{$pk_pelicula}'";
    $resultado=$this->conexion->query($consulta);
    return $resultado;  
  }
   function baja ($pk_pelicula){
    $consulta="UPDATE peliculas SET estatus=0 WHERE pk_pelicula='{$pk_pelicula}'";
    $resultado=$this->conexion->query($consulta);
    return $resultado;  
  }
  function actualizar($pk_pelicula, $titulo, $descripcion, $duracion, $calificacion, $fech_lanzamiento, $fk_genero){
    $consulta="UPDATE peliculas SET titulo='{$titulo}', descripcion='{$descripcion}', duracion='{$duracion}', calificacion='{$calificacion}', fech_lanzamiento='{$fech_lanzamiento}', fk_genero='{$fk_genero}' WHERE pk_pelicula='{$pk_pelicula}' ";
    $resultado=$this->conexion->query($consulta);
    return $resultado;
  }

}

?>