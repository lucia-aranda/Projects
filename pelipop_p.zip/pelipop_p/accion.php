<?php
include ("menu.php");
?>

<body>
	<div align="center" class="container">
		<br><br>
		<style type="text/css">
			h1{  }
		</style>
		<h1 class="kbd">Acción</h1>
		<br><br><br>
		<img src="img/SS.jpg">
		<img src="img/AD.jpg">
		<img src="img/RYF.jpg">
		<img src="img/JW.jpg">
		<img src="img/L.jpg">
		<img src="img/MK.jpg">
		<img src="img/REWRC.jpg">
		<img src="img/LPPS.jpg">
		<img src="img/RBC.jpg">
		<img src="img/12HPS.jpg">
	</div>
	<br><br><br>
</body>