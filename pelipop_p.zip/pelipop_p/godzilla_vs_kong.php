<?php
include("menu.php");
?>

<style type="text/css">
	body{
		background-image: url("img/GVSK_F.jpg");
		opacity: 85%;
		background-repeat: no-repeat;
		background-size: cover;
	}
	h3{
		color: white;
		font-size: 35px;
	}
	h1{
		color: white;
		font-size: 83px;
	}
	.texto_pequeño{
		font-size: 28px;
	}
	.alineacion{
		margin-left: 4%;
	}
	a:hover{
		color: grey;
	}
	.transparent{
		filter: blur(0.8px);
	}
	.size{
		font-size: 23px;
	}
	.pad{
		padding-left: 14%;
	}
</style>
<div class="alineacion fixed-bottom">
	<h3>Al 90% le gustó la película</h3>
	<h1>Godzilla VS Kong</h1>
	<br>
	<h3 class="texto_pequeño"> 1h 53 min | Ciencia ficción</h3>
	<br>
	<div>
		<div class="size col-8">
			
		</div>
		<br>
		<div class="row">
			<div class="col-md-6">
				<a type="button" class="col-3 btn btn-dark btn-lg">Descripción</a>
				<br><br>
				<a type="button" class="col-3 btn btn-light btn-lg">Ver trailer</a>
				<br><br>
				<a type="button" class="col-3 btn btn-light btn-lg">Ver película</a>
			</div>
			<div class="size col-md-2">
				
			</div>
		</div>
	</div>
<!-- info -->
<style>
			.displa{
				display: flex;
			}
			.desc{
				position: absolute;
				top: 350px;
				left: 260px;
				border: 5px;
				height: 190px;
  				width: 650px;
			}
			.landir{
				position: absolute;
				top: 400px;
				left: 900px;
			}
		</style>

	<div class="displa">
					<label class="desc">
					Godzilla y Kong, dos de las fuerzas más poderosas de un planeta habitado por aterradoras criaturas, se enfrentan en un espectacular combate que sacude los cimientos de la humanidad.
					</label>
					<label class="landir">
						Lanzamiento: Mar. 2021
						<br>
						Director: Adam Wingard
					</label>
				</div>
<!-- info -->
	<br><br><br><br>
</div>


<!-- <?php
include("menu.php");
?>

<style type="text/css">
	body{
		background-image: url("img/GVSK_F.jpg");
		opacity: 85%;
		background-repeat: no-repeat;
		background-size: cover;
	}
	h3{
		color: white;
		font-size: 35px;
	}
	h1{
		color: white;
		font-size: 83px;
	}
	.texto_pequeño{
		font-size: 28px;
	}
	.alineacion{
		margin-left: 4%;
	}
	a:hover{
		color: grey;
	}
	.transparent{
		filter: blur(0.8px);
	}
	.size{
		font-size: 23px;
	}
	.pad{
		padding-left: 14%;
	}
	.displa{
		display: flex;
	}
	.desc{
		position: absolute;
		top: 350px;
		left: 220px;
		border: 5px;
		height: 190px;
  		width: 650px;
	}
	.landir{
		position: absolute;
		top: 400px;
		left: 900px;
	}
</style>

<div class="alineacion fixed-bottom">
	<h3>Al 90% le gustó la película</h3>
	<h1>Godzilla VS Kong</h1>
	<br>
	<h3 class="texto_pequeño"> 1h 53 min | Ciencia ficción</h3>
	<br>
	<div class="displa">
		<div class="col-md-6">
			<a type="button" class="col-3 btn btn-dark btn-lg">Descripción</a>
			<br><br>
			<a type="button" class="col-3 btn btn-light btn-lg">Ver trailer</a>
			<br><br>
			<a type="button" class="col-3 btn btn-light btn-lg">Ver película</a>
		</div>
		<div class="size col-8">
			<label class="desc">
				Godzilla y Kong, dos de las fuerzas más poderosas de un planeta habitado por aterradoras criaturas, se enfrentan en un espectacular combate que sacude los cimientos de la humanidad.
			</label>
		</div>
		<div class="size col-md-2">
			<label class="landir">
				Lanzamiento: Mar. 2021
				<br>
				Director: Adam Wingard
			</label>
		</div>
	</div>
</div>

	<br><br><br><br><br><br>
</div> -->