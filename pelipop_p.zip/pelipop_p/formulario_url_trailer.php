<?php 
include("menu.php"); 
?>

<br><br>
<form action="funciones/insertar_url_trailer.php" method="post" class="container">
	<h1>Añadir Nuevo URL de Trailer</h1>

    <br>

 	<label>Insertar url trailer:</label>
    <div class="col-6">
 		<input class="form-control" type="url" name="dato_trailer">
 	</div>
 	
</form>