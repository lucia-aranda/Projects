<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css?a=13">
	<link rel="stylesheet" type="text/css" href="css/estilo.css?a=18">
	<script src="js/bootstrap.js"></script>
</head>

<body>

	<nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <img src="img/Pelipop.png" width="150px">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>

</body>
</html>