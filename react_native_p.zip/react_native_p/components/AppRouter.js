import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import LoginFirebase from "./LoginFirebase";
import Bienvenido from "./Bienvenido";

const Stack=createNativeStackNavigator();

export default function AppRouter({ route }){
    return(
        <NavigationContainer>
            <Stack.Navigator>
            <Stack.Screen name='LoginFirebase' component={LoginFirebase} options={{headerShown: false}}/>
                <Stack.Screen name='Bienvenido' component={Bienvenido} options={({ route }) => ({ title: route.params.user})}/>
            </Stack.Navigator>
        </NavigationContainer>
    )
}