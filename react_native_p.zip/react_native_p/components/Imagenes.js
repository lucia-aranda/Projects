// import * as React from 'react';
// import { Text, View, StyleSheet, Image } from 'react-native';

// export default function AssetExample() {
//   return (
//     <View style={styles.container}>
//       <Text style={styles.paragraph}>
//         Local files and assets can be imported by dragging and dropping them into the editor
//       </Text>
//       <Image style={styles.logo} source={require('../assets/yoshi.png')} />
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     alignItems: 'center',
//     justifyContent: 'center',
//     padding: 24,
//   },
//   paragraph: {
//     margin: 24,
//     marginTop: 0,
//     fontSize: 14,
//     fontWeight: 'bold',
//     textAlign: 'center',
//   },
//   logo: {
//     height: 128,
//     width: 128,
//   }
// });
import { Image, ImageBackground, StyleSheet, Text, View} from "react-native";
export default function Imagenes(){
    const imagen_local = require('../assets/luigi.png')
    const imagen_local_1 = require('../assets/mario.png')
    const imagen_local_2 = require('../assets/peach.png')
return(
    <ImageBackground 
    style={estilos.contenedor}
    blurRadiuses={0}
    source={{ uri:"https://cdn.wallpapersafari.com/32/96/9Ph4mZ.png" }}
    >
        <Image
        source={imagen_local}
        style={estilos.imagen}
        fadeDuration={500}
        />

            <Image
                source={imagen_local_1}
                style={ estilos.imagen1 }
                blurRadius={ 0 }
                fadeDuration={ 500 }
            />
            <Image
                source={imagen_local_2}
                style={ estilos.imagen2 }
                blurRadius={ 0 }
                fadeDuration={ 500 }
            />
    </ImageBackground>
)
}

const estilos = StyleSheet.create({
    contenedor:{
        height: 1000,
        width: 1000,
        felx:1
    },
    // contenedor: {
    //     flex: 1,
    //     backgroundColor: 'skyblue',
    //     justifyContent: 'space-around',
    //     flexDirection: 'row',
    //     alignItems: 'flex-end',
    //     padding: 20
    // },
    imagen: {
        width: 200,
        height: 200,
        top : 180,
        left : 200,
        marginTop: -50,
        borderRadius: 100,
        borderColor: 'black',
        borderWidth: 8,
        // backgroundColor: 'blue',
        // borderRadius: 100,
        //borderWidth: 10
    },
    imagen1: {
        width: 200,
        height: 200,
        top : 193,
        left : 80,
        // backgroundColor: 'blue',
        borderRadius: 100,
        borderColor: 'black',
        borderWidth: 8,
    },
    imagen2: {
        width: 200,
        height: 200,
        top : 200,
        left : 200,
        //backgroundColor: 'blue',
        borderRadius: 100,
        borderColor: 'black',
        borderWidth: 8,
    }
})
//https://reactnative.dev/docs/image