import React from "react"
import { StyleSheet, Text, View } from 'react-native'

export default function Flexbox(){
    return(
        <View style={ estilos.contenedor }>
            <View style={ estilos.cajaRoja }></View>
            <View style={ estilos.cajaAzul }></View>
            <View style={ estilos.cajaAmar }></View>
        </View>
        
    )
}

const estilos = StyleSheet.create({
    contenedor: {
        flex: 1,
        backgroundColor: '#FADA9D'
    },
    cajaRoja: {
        width: 100,
        height: 100,
        top: 0,
        left: 100,
        right: 0,
        bottom: 0,
        flex: 1,
        flexDirection: 'row', //column, row + reverse
        borderWidth: 8,
        position:'absolute',
        borderColor: 'white',
        backgroundColor: '#FD8A8A'
    },
    cajaAzul: {
        width: 280,
        height: 860,
        top: 0,
        left: 200,
        right: 0,
        bottom: 0,
        flex: 1,
        flexDirection: 'row',
        borderWidth: 8,
        position:'absolute',
        borderColor: 'white',
        backgroundColor:'#A8D1D1'
    },
    cajaAmar: {
        width: 100,
        height: 860,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        flex: 1,
        flexDirection: 'row',
        borderWidth: 8,
        position:'absolute',
        borderColor: 'white',
        backgroundColor:'#9EA1D4'
    }
})