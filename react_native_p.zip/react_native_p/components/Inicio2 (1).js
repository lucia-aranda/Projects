import { Alert, SafeAreaView, TouchableOpacity, StyleSheet, Text, TextInput, View, Image } from "react-native"
import { AntDesign } from '@expo/vector-icons';

function Inicio2({navigation}){
const logo = require('../assets/profile.png')

function ver_menu(){
    navigation.navigate('menu_categorias')
}

function ver_login(){
    navigation.navigate('LoginFirebase')
}

return(
    <View style={estilos.contenedor}>
        <View style={estilos.view_logo}>
            <Image
            source={logo}
            style={estilos.logo}
            />
        </View>
        <View style={estilos.view_botones}>
            <Text style={estilos.titulo}>Restaurante</Text>
            <Text style={estilos.subtitulo}>Para comer comida.</Text>
            <TouchableOpacity
            onPress={ver_login}
            activeOpacity={.6}
            style={[estilos.btn_general, estilos.btn_iniciar_sesion]}
            >
                <AntDesign name="user" size={24} color="black"/>
                <Text style={estilos.btn_txt}>
                    &nbsp;Iniciar sesión
                </Text>
            </TouchableOpacity>
            <TouchableOpacity
            onPress={ver_menu}
            activeOpacity={.6}
            style={[estilos.btn_general, estilos.btn_ver_menu]}
            >
                <Text style={[estilos.btn_txt, estilos.txt_menu]}>
                    Ver menú
                </Text>
            </TouchableOpacity>
        </View>
    </View>
)}

const estilos = StyleSheet.create({
    contenedor:{
        flex:1,
        backgroundColor:'white'
    },
    view_logo:{
        flex:1,
        alignItems: 'center'
    },
    view_botones:{
        flex:1,
        justifyContent: 'space-evenly',
        alignItems: 'center'
    },
    logo:{
        flex:1,
        aspectRatio:1
    },
    titulo:{
        fontSize:25,
        fontWeight:'bold'
    },
    subtitulo:{
        fontSize:20,
    },
    btn_general:{
        width:'70%',
        paddingVertical:20,
        alignItems: 'center',
        borderRadius:35,
        flexDirection: 'row',
        justifyContent: 'center'
    },
    btn_iniciar_sesion:{
        backgroundColor:'#eef6fd'
    },
    btn_ver_menu:{
        backgroundColor:'#8a86e2'
    },
    btn_txt:{
        fontSize:20,
        //fontWeight:100
    },
    txt_menu:{
        color:'white'
    }
})

export default Inicio2