
export const firebaseConfig = {
  apiKey: "AIzaSyB240bWHYofRau8ni0lWRUPMsPVVb3Ecwc",
  authDomain: "reactn-lucy-5a.firebaseapp.com",
  projectId: "reactn-lucy-5a",
  storageBucket: "reactn-lucy-5a.appspot.com",
  messagingSenderId: "735006511200",
  appId: "1:735006511200:web:b22eab9d96d1bafbb97305"
};