import {View, Text, Image, StyleSheet, ImageBackground, TouchableOpacity} from 'react-native'
import { Foundation,FontAwesome,Ionicons, AntDesign } from '@expo/vector-icons';
import { ScrollView } from 'react-native';
import CardComida from './CardComida';
import React, {useState, useEffect} from 'react';


export default function OrdenarComida({route}){
    const {url_imagen, nombre_producto, precio_producto} = route.params
    const [count, setCount] = useState(1)
    const[prize,setPrize] = useState(precio_producto);
    useEffect(() => {
    setPrize(() => count*precio_producto)
    }, [count]);
    //setCount = (0)
    const sugerencias = [
        {
            imagen:"https://i.postimg.cc/dQg8txTJ/012-pizza-slice.png",
            texto:"Pizza"
        },
        {
            imagen:"https://i.postimg.cc/fWS9Ffqp/019-steak.png",
            texto:"Carne"
        },
        {
            imagen:"https://i.postimg.cc/jj8fVgb0/018-soft-drink.png",
            texto:"Bebida"
        },
        {
            imagen:"https://i.postimg.cc/hP7fy4vB/002-soda.png",
            texto:"Soda"
        },
        {
            imagen:"https://i.postimg.cc/vZhg9qDg/025-cocktail.png",
            texto:"Cocktel"
        },
        {
            imagen:"https://i.postimg.cc/8zmW4kXC/015-ice-cream.png",
            texto:"Helado"
        },
        {
            imagen:"https://i.postimg.cc/7bvY87hy/010-red.png",
            texto:"Vino"
        },
        {
            imagen:"https://i.postimg.cc/C5nLQJFN/009-mojito.png",
            texto:"Mojito"
        }
    ]
    return (
        <View style={estilos.contenedor}>
            {/* header */}
            <View style={estilos.header}>
            <AntDesign name="left" size={24} color="black" />
                <Text>Pedido</Text>
                <AntDesign name="infocirlceo" size={24} color="black" />
            </View>

            {/* imagen_principal */}
            <View style={estilos.imagen_principal}>
                <Image style={estilos.imagen} source={{uri: url_imagen}} />
                {/* corazon */}
                <TouchableOpacity style={estilos.corazon}>
                <AntDesign name="hearto" size={24} color="black" />
                </TouchableOpacity>
            </View>

            

            {/* descripcion_precio */}
            <View style={estilos.descripcion_precio}>
                <View style={estilos.desc}>
                    <Text style={estilos.txt_desc}>{nombre_producto}</Text>
                    <Text style={estilos.txt_desc}>${prize}</Text>
                </View>
                <Text>{count} Pz.</Text>
            </View>

            {/* sugerencias */}
            <View style={estilos.sugerencias}>
                <ScrollView horizontal={true}>
                    {sugerencias.map((item,indice)=>(
                        <CardComida 
                        key={indice}
                        imagen={item.imagen} 
                        texto={item.texto}
                        />
                    ))}
                    
                </ScrollView>
            </View>

            {/* botones */}
            <View style={estilos.botones}>
                <View style={estilos.mas_botones}>
                    <View style={estilos.btn_sumar_restar}>
                        <TouchableOpacity style={estilos.fondo_icono} onPress={()=>setCount(count+1)}>
                            <AntDesign name="plus" size={24} color="black"/>
                        </TouchableOpacity>
                        </View>
                        <Text>{count}</Text>
                        <View style={estilos.btn_sumar_restar}>
                        <TouchableOpacity style={estilos.fondo_icono} onPress={()=>setCount(count-1)} disabled={count===1}>
                            <AntDesign name="minus" size={24} color="black"/>
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={estilos.view_carrito}>
                    <TouchableOpacity style={estilos.btn_carrito}>
                        <Text style={estilos.txt_comprar}>
                            Add to cart
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    )
}

const estilos = StyleSheet.create({
    contenedor:{
        flex:1,
        backgroundColor:'white'
    },
    header:{
        flex:1,
        backgroundColor:'#A09F57',
        flexDirection:'row',
        paddingHorizontal: 20,
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    imagen_principal:{
        flex:5,
        backgroundColor:'#E8D2A6',
        margin:20,
        borderRadius: 40
    },
    descripcion_precio: {
        flex:1,
        backgroundColor:'white',
        justifyContent: 'center',
        margin:10
    },
    sugerencias:{
        flex:2,
        backgroundColor:'white'
    },
    botones:{
        flex:1,
        backgroundColor:'#A09F57',
        justifyContent: 'space-around',
        flexDirection:'row'
    },
    txt_comprar:{
        color:'black',
        fountWeight:'bold',
        fontSize:16
    },
    mas_botones: {
        flex:1,
        borderWidth:2,
        borderColor:'black',
        margin:20,
        flexDirection:'row',
        borderRadius:30,
        alignItems: 'center',
        justifyContent: 'space-evenly'
    },
    fondo_icono:{
        backgroundColor:'#B7B78A',
        padding:5,
        borderRadius:100
    },
    btn_sumar_restart: {
        flex:1,
        margin:20,
        justifyContent: 'space-evenly'
    },
    view_carrito:{
        flex:1
    },
    btn_carrito:{
        flex:2,
        margin:20,
        backgroundColor:'#E8D2A6',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius:30
    },
    imagen: {
        width:370,
        height:370,
        alignSelf:'center',
        justifyContent: 'center',
        top:20
    },
    corazon:{
        position:"absolute",
        bottom:20,
        right:20,
        backgroundColor:"white",
        padding:15,
        borderRadius:20
    },
    desc:{
        justifyContent: 'space-between',
        flexDirection: 'row'
    },
    txt_desc:{
        fontSize:20
    }
})
//https://icons.expo.fyi/