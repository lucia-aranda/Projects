// npm i @expo/vector-icons
// comando para descargar iconos paqueteria