// import Holamundo from "./components/Holamundo";

// export default function App(){

//     return(
//       <Holamundo></Holamundo>
//     )
//   }
//import Holamundo from "./componentes/Holamundo";

//CODIGO DE HOLA MUNDO CON FONDO BLANCO

import Flexbox from "./components/Flexbox.js";
import Saludar from "./components/Saludar.js";
import Imagenes from "./components/Imagenes.js";
import Iconos from "./components/Iconos.js";
import OrdenarComida from "./components/OrdenarComida.js";
import PS from "./components/PS.js";
import Fondos from "./components/Fondos.js";
import ProductoIndividual from "./components/ProductoIndividual.js";
// import Login from "./components/Login.js";
import Inicio from "./components/Inicio.js";
import MenuProductos from "./components/MenuProductos.js";
import Router from "./components/Router.js";
import LoginFirebase from "./components/LoginFirebase.js";

export default function App(){

  var nombre = "Elian"
  var apellido = "Reyes"

    return(
        <>
        {/* <Saludar nombre="Jesus" apellido="Oleta"/>
        <Saludar nombre="Jorge" apellido="Estrada"/>
        <Saludar nombre="Fer" apellido="Gonzalez"/>
        <Saludar nombre="Lucas" apellido="Cuevas"/>
        <Saludar nombre="Valeria" apellido="Toledo"/>
        <Saludar nombre={nombre} apellido={apellido}/> */}

        

        {/* <Flexbox/> */}

        {/* <Textos/> */}

        {/* <Imagenes/> */}

        {/* <Iconos/> */}

        {/* <OrdenarComida/> */}

        {/* <PS/> */}

        {/* <Fondos/> */}


        {/* <Login/> */}

        {/* <Inicio/> */}

        <Router/>


        </>
    )
}
//ctrl+llave que cierra