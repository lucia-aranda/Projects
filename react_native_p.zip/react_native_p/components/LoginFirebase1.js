import React, {useState} from 'react'
import {Alert, Button, Stylesheet, Text, TextInput, View} from 'react-native'
import {getAuth, signInWithEmailAndPassword} from 'firebase/auth';
import { initializeApp } from 'firebase/app';
import {firebaseConfig} from '../firebase-config';

function LoginFirebase ({navigation}){
    const [datosUsuario,setDatosUsuario]=useState({usuario:'',pw:''})
    const app = initializeApp(firebaseConfig)
    const auth = getAuth(App);
    const cambiar_pantalla = () => {
        alert('Iniciaste sesión')
        navigation.navigate('admin',{ usuario: datosUsuario.usuari})
        .catch((error)=>{
            const errorCode = error.code;
            const errorMsg = error.message;
            if(errorCode == 'auth/invalid-email'){
                Alert.alert('Datos incorrectos', 'Verifica tus credenciales')
            } else {
                alert(errorMsg)
            }
        });
    }
}