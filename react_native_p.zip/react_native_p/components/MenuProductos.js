import React, { useEffect, useState } from "react"
import {ScrollView, StyleSheet, Text, View} from 'react-native'
import {collection, getFirestore, getDocs} from "firebase/firestore/lite";
import { initializeApp } from "firebase/app";
// importancia dde la API KEY
import { firebaseConfig } from './firebase_config';
import ProductoIndividual from "./ProductoIndividual";

function MenuProductos({route}){
    const {id} = route.params
    const [productos, setProductos] = useState([])
    const app = initializeApp(firebaseConfig)
    const db = getFirestore(app)

    useEffect(() => {
        let c = collection(db, 'categoria_menu', id, 'productos')

        getDocs(c)
        .then(datos => {
            var arreglo_de_productos = []
            datos.forEach((doc) =>{
                arreglo_de_productos.push({
                    id:doc.id,
                    ...doc.data()
                })
            });
            console.log(arreglo_de_productos);
            setProductos(arreglo_de_productos)
        })
    }, [])

    return (
        <View style={estilos.contenedor}>
            <ScrollView contentContainerStyle={estilos.scroll}>
            { productos.map((item, index) => (
                <ProductoIndividual
                key={index}
                url_imagen={item.url_imagen}
                nombre_producto={item.nombre}
                precio_producto={item.precio}
                />
            ))}
            </ScrollView>
        </View>
    )

}

export default MenuProductos

const estilos = StyleSheet.create({
    contenedor:{
        flex:1,
        backgroundColor:'White'
    },
    scroll:{
        flexDirection:'row',
        flexWrap:'wrap',
        justifyContent: 'space-evenly'
    }
})