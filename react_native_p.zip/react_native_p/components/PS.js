import React from 'react'
import {Text, TouchableOpacity, View, StyleSheet, Image, ImageBackground} from 'react-native'
import { AntDesign } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';
import { Ionicons } from '@expo/vector-icons';
import { Octicons } from '@expo/vector-icons';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { MaterialIcons } from '@expo/vector-icons';

function Iconos(){
    const imagen_local = require('../assets/tlou.jpg')
    const imagen_local_1 = require('../assets/hplc.jpg')
    const imagen_local_2 = require('../assets/ds.jpg')
    const imagen_local_3 = require('../assets/gow.png')
    const imagen_local_4 = require('../assets/profile.png')
    return(
        <View style={estilos.contenedor}>
            <View style={ estilos.caja }></View>
            <Text style={ estilos.texto }>Zabaguata</Text>
            <Text style={ estilos.texto2 }>Recently played</Text>
            <Text style={ estilos.texto1 }>ScarrXandeerAshes</Text>
            <Text style={ estilos.texto0 }>Edit profile</Text>
            <Text style={ estilos.texto00 }>Privacy</Text>
            <AntDesign name="leftcircle" size={50} color='#303030' style={estilos.icono}/>
            <FontAwesome5 name="edit" size={24} color="white" style={estilos.icono1}/>
            <Ionicons name="options-outline" size={29} color="white" style={estilos.icono2}/>
            <Octicons name="comment-discussion" size={24} color="white" style={estilos.icono3}/>
            <MaterialCommunityIcons name="sticker-emoji" size={24} color="white" style={estilos.icono4}/>
            <MaterialIcons name="keyboard-arrow-right" size={35} color="white" style={estilos.icono5}/>
            <Image
            source={imagen_local}
            style={estilos.imagen}
            fadeDuration={500}
            />
            <Image
            source={imagen_local_1}
            style={estilos.imagen_1}
            fadeDuration={500}
            />
            <Image
            source={imagen_local_2}
            style={estilos.imagen_2}
            fadeDuration={500}
            />
            <Image
            source={imagen_local_3}
            style={estilos.imagen_3}
            fadeDuration={500}
            />
            <Image
            source={imagen_local_4}
            style={estilos.imagen_4}
            fadeDuration={500}
            />

        </View>
        
    )
}
export default Iconos
const estilos = StyleSheet.create({
    contenedor:{
        height: 1000,
        width: 1000,
        felx:1,
        backgroundColor:'#202121'
    },
    icono:{
        width: 100,
        height: 100,
        top : 700,
        left : 50
    },
    icono1:{
        width: 100,
        height: 100,
        top : 90,
        left : 200
    },
    icono2:{
        width: 200,
        height: 200,
        top : -10,
        left : 270
    },
    icono3:{
        width: 300,
        height: 200,
        top : -457,
        left : 40
    },
    icono4:{
        width: 100,
        height: 100,
        top : -650,
        left : 410
    },
    icono5:{
        width: 100,
        height: 100,
        top : -380,
        left : 420
    },
    imagen: {
        width: 200,
        height: 200,
        top : -280,
        left : 250,
        marginTop: 50,
        borderRadius: 15,
        borderWidth: 8
    },
    imagen_1: {
        width: 200,
        height: 200,
        top : -445,
        left : 35,
        marginTop: -35,
        borderRadius: 15,
        borderWidth: 8,
        //borderWidth: 10
    },
    imagen_2: {
        width: 200,
        height: 200,
        top : 100,
        left : 35,
        marginTop: -958,
        borderRadius: 15,
        borderWidth: 8,
        //borderWidth: 10
    },
    imagen_3: {
        width: 200,
        height: 200,
        top : -190,
        left : 250,
        marginTop: 90,
        borderRadius: 15,
        borderWidth: 8,
        //borderWidth: 10
    },
    imagen_4: {
        width: 100,
        height: 100,
        top : -170,
        left : 200,
        marginTop: -570,
        borderRadius: 105,
        borderWidth: 8,
        //borderWidth: 10
    },
    texto: {
        fontSize: 10,
        color: 'white',
        top : 260,
        left : 219
    },
    texto0: {
        fontSize: 10,
        color: 'white',
        top : 260,
        left : 180
    },
    texto00: {
        fontSize: 10,
        color: 'white',
        top : 244,
        left : 265
    },
    texto2: {
        fontSize: 15,
        color: 'white',
        top : 420,
        left : 37
    },
    texto1: {
        fontSize: 23,
        color: 'white',
        top : 180,
        left : 130
    },
    caja: {
        width: 410,
        height: 60,
        top: 370,
        left: 37,
        right: 0,
        bottom: 0,
        flex: 1,
        borderRadius: 5,
        flexDirection: 'row', //column, row + reverse
        //borderWidth: 2,
        position:'absolute',
        //borderColor: 'white',
        backgroundColor: '#2e2d2d'
    }
})
//https://icons.expo.fyi/