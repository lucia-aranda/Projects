// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD1lvUfdxXLG6yE9sGCCF8XnBM_w0m8ewE",
  authDomain: "react-native-lucy-5a.firebaseapp.com",
  projectId: "react-native-lucy-5a",
  storageBucket: "react-native-lucy-5a.appspot.com",
  messagingSenderId: "385897556086",
  appId: "1:385897556086:web:e51b28b4d169dee9ee5757"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);