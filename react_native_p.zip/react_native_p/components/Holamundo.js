
import { StyleSheet, Text, View } from "react-native";

export default function Holamundo(){

    return(
      <View style={ estilos.contenedor }>
      <Text style={ estilos.texto }>HELLO WORLD</Text>
      </View>
    )
  }

  const estilos = StyleSheet.create({
    contenedor: {
        backgroundColor: 'yellow',
        flex: 1,
        textAlign: 'center', 
        justifyContent: 'center'
    },
    texto: {
        fontSize: 50,
        textAlign: 'center'
       
  }
  })