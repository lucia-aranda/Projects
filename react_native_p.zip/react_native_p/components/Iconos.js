import React from 'react'
import {Text, View} from 'react-native'
import { AntDesign } from '@expo/vector-icons';

function Iconos(){
    return(
        <View>
            <Text>Icon</Text>
            <AntDesign name="leftcircle" size={100} color="black"/>
        </View>
    )
}
export default Iconos
//https://icons.expo.fyi/