import React, { useEffect, useState } from "react"
import { Alert, SafeAreaView, TouchableOpacity,ScrollView, StatusBar, StyleSheet, Image, Text, TextInput, View } from "react-native"
//importancia de funciones de firebase
import { getAuth, signInWithEmailAndPassword} from "firebase/auth"
import { initializeApp } from "firebase/app";
import CategoriaComponent from "./CategoriaComponent";
// importancia dde la API KEY
import { MaterialIcons, AntDesign } from "@expo/vector-icons";
import { firebaseConfig } from './firebase_config';
import {collection, getFirestore, getDocs} from 'firebase/firestore/lite';

function MneuCategorias() {
    const [categorias, setCategorias] = useState([])
    const app = initializeApp(firebaseConfig)
    const db = getFirestore(app)

    useEffect(()=>{

        let c = collection(db,'categoria_menu')
        getDocs(c)
        .then(datos=>{
            
            var arreglo_de_categorias = []

            datos.forEach((doc) =>{
                arreglo_de_categorias.push({
                    id: doc.id,
                    ...doc.data()
                })
            });
            console.log(arreglo_de_categorias);
            setCategorias(arreglo_de_categorias)
        })
    }, [])

    return(
        <View style={estilos.contenedor}>
            <StatusBar/>
            <View style={estilos.view_categorias}>
                <ScrollView>
                    {categorias.map((item, index)=>(
                        <CategoriaComponent
                        key={index}
                        id_categoria={item.id}
                        titulo={item.nombre_categoria}
                        url_imagen={item.url_imagen ?? 'https://i.posting.cc/KYQzkRqn/007-pancake.png'}
                        />
                    ))}
                </ScrollView>
            </View>
            
            <View style={estilos.view_menu_abajo}>
                <TouchableOpacity style={estilos.btn_opciones}>
                    <MaterialIcons name="menu-book" size={24} color="black"/>
                    <Text>Categorias</Text>
                </TouchableOpacity>

                <TouchableOpacity style={estilos.btn_opciones}>
                    <AntDesign name="search1" size={24} color="black"/>
                    <Text>Buscador</Text>
                </TouchableOpacity>

                <TouchableOpacity style={estilos.btn_opciones}>
                    <AntDesign name="user" size={24} color="black"/>
                    <Text>Mi pedido</Text>
                </TouchableOpacity>

            </View>


        </View>
    )
}

const estilos = StyleSheet.create({
    contenedor:{
        flex:1,
        backgroundColor:'white'
    },
    view_categorias:{
        flex:11
    },
    view_menu_abajo: {
        flex:1,
        flexDirection:'row',
        borderTopWidth:1,
        justifyContent: 'space-around'
    },
    btn_opciones:{
        width:100,
        justifyContent: 'center',
        alignItems: 'center'
    }
})
export default MneuCategorias