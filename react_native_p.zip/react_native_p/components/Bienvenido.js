import React from 'react'
import { View, Text, StyleSheet, Image } from 'react-native'

export default function Bienvenido({ route }) {
 
    const { user } = route.params;

  return (
    <View style={ estilos.contenedor } >
            <Text style={ estilos.texto }>Bienvenido { user }, te regalamos este pez</Text>
            <Image
            style={estilos.imagen}
            source={ require('../assets/oso.jpg' )}
            />
    </View>
  )
}

const estilos = StyleSheet.create({
    contenedor: {
        flex:1,
        backgroundColor: 'white',
        alignItems:'center',
    },
    body:{
        flex:1,
        flexDirection:'row',
        paddingHorizontal:20, 
    },
    texto:{
        fontSize:24,
        justifyContent:'center',
        position:'relative',
        alignSelf:'center',
        textAlign:'center'
    },
    imagen:{
        width: 400,
        height: 500,
        top:80,
        justifyContent:'center',
        position:'absolute'
    }
})


