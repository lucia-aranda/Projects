import React from 'react'
import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native'
import {color_aleatorio} from '../functions/colores'
import { useNavigation } from '@react-navigation/native'

function ProductoIndividual({nombre_producto, url_imagen, precio_producto}){
    const backgroundColor = color_aleatorio()
    const navigation = useNavigation()

    function cambiar_pantalla(){
        navigation.navigate('ordenar_comida',{url_imagen, nombre_producto, precio_producto})
    }

    return(
        <TouchableOpacity style={estilos.contenedor} onPress={cambiar_pantalla}>
            <View style={{
                ...estilos.view_imagen,
                backgroundColor
            }}>
            <Image 
            style={estilos.imagen}
                source={{uri: url_imagen}}/>
            </View>
            <View style={estilos.view_txt}>
                <Text>
                    {nombre_producto}
                </Text>
                <Text style={estilos.txt_precio}>
                    {precio_producto}
                </Text>
            </View>
        </TouchableOpacity>
    )
}

export default ProductoIndividual

const estilos = StyleSheet.create({
    contenedor: {
        marginBottom: 20,
        maxWidth: 150,
        paddingTop: 20
    },
    view_imagen:{
        width: 150,
        height: 100,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 25
    },
    imagen:{
        width: 60,
        height: 60
    },
    txt_precio:{
        fontWeight: 'bold',
        color:'purple'
    },
    view_txt:{
        flexDirection: 'row',
        justifyContent: 'space-between'
    }
})