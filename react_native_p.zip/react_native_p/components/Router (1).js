import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
//import LoginFirebase from "./LoginFirebase";
import Inicio from "./Inicio.js";
import LoginFirebase from './LoginFirebase.js';
import Inicio2 from "./Inicio2.js";
import MneuCategorias from './MenuCategorias.js';

const Stack = createNativeStackNavigator();

export default function Router() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Principal" component={Inicio2} options={{headerShown:false}}/>
        <Stack.Screen name="menu_categorias" component={MneuCategorias} options={{headerShown:false}}/>
        <Stack.Screen name="LoginFirebase" component={LoginFirebase} options={{headerShown:false}}/>
        <Stack.Screen name="Bienvenido" component={Inicio} options={({route}) => ({title: route.params.usuari})}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}