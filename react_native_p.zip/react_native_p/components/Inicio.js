// In App.js in a new project

import * as React from 'react';
import { View, Text, StyleSheet, Image, ImageBackground } from 'react-native';


export default function Inicio({route}) {
  const{usuari} = route.params;
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{fontSize:30}}>Bienvenida, {usuari}</Text>
    </View>
  );
}
//https://reactnavigation.org/docs/navigating