import React, { useState } from "react"
import { useNavigation } from "@react-navigation/native";
import { Alert, SafeAreaView, TouchableOpacity, StyleSheet, Text, TextInput, View, Image } from "react-native"
//importancia de funciones de firebase
import { getAuth, signInWithEmailAndPassword} from "firebase/auth"
import { initializeApp } from "firebase/app";
// importancia dde la API KEY
import { firebaseConfig } from './firebase_config';

function CategoriaComponent({titulo, url_imagen, id_categoria}){
    
    const navigation = useNavigation()
    
    var colores=[
        '#F7DB6A',
        '#7AA874',
        '#FFBF9B',
        '#97DEFF',
        '#FFBFA9'
    ]

    var elegido = colores[Math.floor(Math.random()*colores.length)]

    function cambiar_pantalla(id){
        navigation.navigate('menu_productos',{id})
    }

    return(
        <>
            <TouchableOpacity
            activeOpacity={.6}
            style={{
                ...estilos.contenedor,
                backgroundColor: elegido
            }}
            onPress={()=> cambiar_pantalla(id_categoria)}
            >

            <Text style={estilos.txt_titulo}>{titulo}</Text>
            <Image
            style={{width:100, height:100}} 
            source={{uri:url_imagen}}
            />
            </TouchableOpacity>
            <View style={estilos.borde}/>
        </>
    )
}
export default CategoriaComponent

const estilos = StyleSheet.create({
    contenedor:{
        height:100,
        margin:20,
        backgroundColor: '#eae8ff',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal:15
    },
    borde:{
        borderTopWidth:1,
        width:50,
        alignSelf: 'center',
        borderColor:'gray'
    },
    txt_titulo:{
        fontSize: 20
    }
})
