import { Text } from 'react-native'

function Saludar({ nombre, apellido }) {
  console.log(nombre);

  return (
    <Text>Saludar a { nombre } { apellido }</Text>
  ) 
}

export default Saludar


