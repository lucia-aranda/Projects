import React from "react";
import {View, Text, Image, StyleSheet,TouchableOpacity} from "react-native"
import { ScrollView } from "react-native";

function CardComida({imagen,texto}){
    console.log(imagen);
    return(
        <TouchableOpacity style={estilos.contenedor} activeOpacity={.10}>
            <Image style={estilos.imagen} source={{uri:imagen}} />
            <Text style={estilos.txt}>{texto}</Text>
            
        </TouchableOpacity>
    )
}
export default CardComida
const estilos = StyleSheet.create({
    imagen:{
        width: 100,
        height: 100,
        margin:10,
        alignSelf:'center',
        justifyContent: 'space-between'
    },
    txt:{
        alignSelf: 'center'
    },
    contenedor:{
        justifyContent: 'center',
        paddingHorizontal:10
    }
})