import {View, Text, Image, StyleSheet, ImageBackground, TouchableOpacity, ActivityIndicator } from 'react-native'
import { Foundation,FontAwesome,Ionicons, AntDesign } from '@expo/vector-icons';
import { ScrollView } from 'react-native';
import CardComida from './CardComida';
import React, {useState, useEffect} from 'react';

export default function Fondos(){
    const [img, setImg] = useState("https://i.pinimg.com/736x/5b/28/4b/5b284b726108559820c7053e07ae1d82.jpg")
    const [cargando, setCargando] = useState(true)
    return(
        <ImageBackground style={estilos.contenedor} source={{uri:img}} onLoadEnd={ () => setCargando( false ) }>
            
            {/* header */}
            <View style={estilos.header}>
                {/* <Text style={{color:"white", left:7, fontSize:30}}>Fondos</Text> */}
                { cargando && <ActivityIndicator size="large" /> }
                <Text style={{color:"white", left:7, fontSize:30}}> { cargando ? "Cargando":"Fondo listo" }</Text>
            </View>
              {/* boton 1 */}
            <View style={estilos.view_carrito}>
                    <TouchableOpacity style={estilos.btn_carrito} onPress={()=>{setImg("https://cdna.artstation.com/p/assets/images/images/025/352/586/large/neon-3d-pc.jpg?1585537966") 
                    setCargando( true ) }} >

                        <Text style={estilos.txt_comprar}>
                            Cozy
                        </Text>
                    </TouchableOpacity>
            </View>
            {/* boton 2 */}
            <View style={estilos.view_carrito1}>
                    <TouchableOpacity style={estilos.btn_carrito1} onPress={()=>{setImg("https://img.freepik.com/premium-photo/cute-dinosaur-3d-render_303714-1148.jpg?w=2000") 
                    setCargando( true )}}>
                        <Text style={estilos.txt_comprar1}>
                            Dino
                        </Text>
                    </TouchableOpacity>
            </View>
             {/* boton 3 */}
             <View style={estilos.view_carrito2}>
                    <TouchableOpacity style={estilos.btn_carrito2} onPress={()=>{setImg("https://i.pinimg.com/550x/7a/25/0d/7a250d60b36b8f60c1d9185ba477a11b.jpg")  
                    setCargando( true )}}>
                        <Text style={estilos.txt_comprar2}>
                            Rosa
                        </Text>
                    </TouchableOpacity>
            </View>
            </ImageBackground>
    )
}

const estilos = StyleSheet.create ({
    contenedor:{
        flex:1,
        backgroundColor:'black',
        justifyContent: 'center'
    },
    header:{
        flex:1,
        bottom: -100,
        //flexDirection:'center',
        //paddingHorizontal: 20,
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    txt_comprar:{
        color:'black',
        fountWeight:'bold',
        fontSize:16
    },
    view_carrito:{
        flex:1
    },
    btn_carrito:{
        flex:1,
        margin:165,
        width:135,
        height:100,
        bottom:-130,
        left: 20,
        backgroundColor:'white',
        justifyContent: 'space-evenly',
        alignItems: 'center',
        borderRadius:30,
    },
    txt_comprar1:{
        color:'black',
        fountWeight:'bold',
        fontSize:16
    },
    view_carrito1:{
        flex:2,
        position:'absolute'
    },
    btn_carrito1:{
        flex:1,
        margin:180,
        width:140,
        height:100,
        bottom:-70,
        backgroundColor:'white',
        justifyContent: 'space-evenly',
        alignItems: 'center',
        borderRadius:30,
        //bottom: -50
    },
    txt_comprar2:{
        color:'black',
        fountWeight:'bold',
        fontSize:16
    },
    view_carrito2:{
        flex:2,
        position:'absolute'
    },
    btn_carrito2:{
        flex:1,
        margin:180,
        width:140,
        height:100,
        bottom:200,
        backgroundColor:'white',
        justifyContent: 'space-evenly',
        alignItems: 'center',
        borderRadius:30,
        //bottom: -50
    }
})