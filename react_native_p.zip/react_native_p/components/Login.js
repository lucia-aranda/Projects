import React, {useState} from 'react';
import {SafeAreaView, StyleSheet, TextInput,View, TouchableOpacity,Text, ImageBackground} from 'react-native';

export default function Login({navigation}){

  const [usuari, setUsername] = useState('');
  const [contra, setPassword] = useState('');

  const datos = () => {
    if (usuari !== '' && contra !== '')
    {
      navigation.navigate('Inicio',{usuari})
    }
    if (usuari.trim() === '' || contra.trim() === '')
    {
      alert("Datos incorrectos.")
      return;
    }
  }

  return (
    <ImageBackground style={styles.contenedor} source={{uri:"https://e0.pxfuel.com/wallpapers/943/992/desktop-wallpaper-primrose-background-on-green-by-ruth-black-for-stocksy-united-iphone-landscape-flower-background-flower-phone-cute-green.jpg"}}>
      {/* <TextInput
        style={styles.input}
        onChangeText={onChangeText}
        value={text}
      /> */}
      <Text style={styles.texto}>Bienvenido</Text>
      <TextInput
        style={styles.input}
        onChangeText={setUsername}
        value={usuari}
        placeholder="Ingresa tu usuario"                                                                             
        keyboardType="varchar"
      />
      <TextInput
        style={styles.input}
        onChangeText={setPassword}
        secureTextEntry
        value={contra}
        placeholder="Ingresa tu contraseña"
        keyboardType="varchar"
      />
      <View style={styles.view_carrito}>
            <TouchableOpacity style={styles.btn_carrito} onPress={datos}>
                <Text style={styles.txt_comprar}>
                    INICIAR SESIÓN
                </Text>
            </TouchableOpacity>
        </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
    contenedor:{
        flex:1,
        backgroundColor:'black',
        justifyContent: 'center'
    },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 0,
    bottom: -200,
    padding: 10,
    borderRadius:30,
    backgroundColor:'white'
  },
  view_carrito:{
    flex:1
},
btn_carrito:{
    margin:15,
    width:230,
    height:50,
    bottom:-200,
    left: 115,
    backgroundColor:'white',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    borderRadius:30,
    textAlign: 'center'
},
txt_comprar:{
    color:'black',
    fountWeight:'bold',
    fontSize:16
},
texto:{
    fontSize:30,
    textAlign: 'center',
    bottom:-200
}
});
