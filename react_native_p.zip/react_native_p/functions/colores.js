export function color_aleatorio(){
    var colores=[
        '#F7DB6A',
        '#7AA874',
        '#FFBF9B',
        '#97DEFF',
        '#FFBFA9'
    ]

    return colores[Math.floor(Math.random()*colores.length)]
}