import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';

class Responsivo extends StatelessWidget {
  const Responsivo({super.key});

  @override
  Widget build(BuildContext context) {
    //double width = Get.width;
    double width = context.width;
    return Scaffold(
      appBar: CustomAppbar(titulo: "Responsivo $width", color: const Color.fromARGB(255, 255, 213, 0)),
      body: Center(
        child: Flex(
          //direction: Axis.vertical,
          direction: width < 768 ? Axis.vertical : Axis.horizontal,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              margin: EdgeInsets.all(10),
              width: 300,
              height: 200,
              color: Colors.blue,
              child: Image.asset("../assets/perros/perro8.jpg")
            ),
            Container(
              margin: EdgeInsets.all(10),
              width: 300,
              height: 200,
              color: Colors.green,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text("esto es un texto"),
                  Text("esto también es un texto"),
                  Text("y esto"),
                ],
              )
            ),
            // Text("esto es un texto"),
            // Text("esto también es un texto"),
            // Text("y esto"),
          ],
        )
        //Text("esto es un texto"),
      )
    );
  }
}