import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';

class Botones extends StatelessWidget {
  const Botones({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo: "Botones", color: Color.fromARGB(255, 243, 62, 34)),
      drawer: CustomDrawer(),
      body: Center(
        child: Column(
          children: [
            Text("Botones"),
            TextButton(
              onPressed: () {}, 
              style: TextButton.styleFrom(
                minimumSize: Size(200, 20), 
                foregroundColor: Colors.red
              ),

              child: Text('BTN1')),
              ElevatedButton(
                onPressed: () {}, 
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(200, 20), 
                  foregroundColor: const Color.fromARGB(255, 244, 119, 110)
                ),
                child: Text('BTN2')),
                
                OutlinedButton(
                onPressed: () {}, 
                style: OutlinedButton.styleFrom(
                  minimumSize: Size(200, 20), 
                  side:BorderSide(color: Colors.red),
                  foregroundColor: Colors.red
                ),child: Text('BTN3')),
                
                IconButton(
                  onPressed: () {},
                  icon: Icon(Icons.call),
                ),
                
                FloatingActionButton(
                  onPressed:(){
                    Get.toNamed('/images');
                    },
                  child: Icon(Icons.add),),
                
          ]
          
        ),
      ),
    
    );
  }
}