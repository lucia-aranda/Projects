import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';

class Cuadros4 extends StatelessWidget {

  const Cuadros4({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo:'Cuadros', color: const Color.fromARGB(255, 156, 250, 159)),
      body: Container(
        padding: EdgeInsets.all(10),

        child: Column(
          
            children: [

            //-------------------------------------------------------------------------------------------
            Expanded( 
              
              child: Container(
                color: Colors.blue,
              child: Column(
                children: [
                  
                  //codigo
                  Expanded(
              flex: 2,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      color: Colors.purple,
                      margin: EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Expanded(
                            flex: 4,
                            child: Container(
                              color: Colors.pink,
                              margin: EdgeInsets.all(4.0),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              color: Colors.white,
                              margin: EdgeInsets.all(4.0),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              color: Colors.white,
                              margin: EdgeInsets.all(4.0),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.purple,
                      margin: EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Expanded(
                            flex: 3,
                            child: Container(
                              color: Colors.green,
                              margin: EdgeInsets.all(4.0),
                            ),
                          ),
                          Expanded(
                            child: Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    color: Colors.orange,
                                    margin: EdgeInsets.all(4.0),
                                  ),
                                ),
                                Expanded(
                                  child: Container(
                                    color: Colors.orange,
                                    margin: EdgeInsets.all(4.0),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

                  //codigo
                  
                ],
              )
                  
            )),

            
            //-------------------------------------------------------------------------------------------

            Expanded(
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      color: Colors.yellow,
                      margin: EdgeInsets.all(8.0),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.yellow,
                      margin: EdgeInsets.all(8.0),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.yellow,
                      margin: EdgeInsets.all(8.0),
                    ),
                  ),
                ],
              ),
            ),
          ],
        )

      )
    );
  }
}