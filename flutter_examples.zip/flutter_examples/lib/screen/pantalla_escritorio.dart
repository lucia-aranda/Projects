import 'package:flutter/material.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';

class PantallaEscritorio extends StatelessWidget {
  const PantallaEscritorio({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo: "Escritorio", color: Colors.orange),
      body: Row(
        children: [
        CustomDrawer(),
        Text('Pantalla Escritorio')],
      )
    );
  }
}