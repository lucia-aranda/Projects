import 'package:flutter/material.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:get/get.dart';

 class Formulario extends StatefulWidget {
  
  const Formulario({super.key});

  @override
  State<Formulario> createState() => _FormularioState();
}

class _FormularioState extends State<Formulario> {

  final formulario_key = GlobalKey<FormState>();
  final titulo_controller = TextEditingController();
  final descripcion_controller = TextEditingController();
  final supabase = Supabase.instance.client;

  bool guardando = false;

	guardarNota() async {

		setState(() {
			guardando = true;
		});

		try {
			await supabase
				.from('notas')
				.insert({
					'titulo': titulo_controller.text,
					'descripcion': descripcion_controller.text,
					'estatus': 'Pendiente'
				});

			Get.snackbar('Guardado'	, 'Nota guardada');
		} catch (e) {

			print(e);
			Get.snackbar(
				'Error',
				'No se pudo guardar la nota',
				backgroundColor: Colors.red,
				colorText: Colors.white
			);

		} finally {
			setState(() {
				guardando = false;
			});
		}
	}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo: "Formulario", color: Color.fromARGB(255, 43, 167, 84)),
      drawer: CustomDrawer(),
      body: Form(
        key: formulario_key,
        child: Column(
          children:[
            TextFormField(
              controller: titulo_controller,
              decoration: InputDecoration(
                hintText: 'Ingresa un título'
              ),
              autovalidateMode: AutovalidateMode.onUserInteraction,
              validator: (value) {
                if (value!.isEmpty){
                  return 'Ingresa un título';
                }
                return null;
              },
            ),
            TextFormField(
              controller: descripcion_controller,
              decoration: InputDecoration(
                hintText: 'Ingresa una descripción'
              ),
              minLines: 1,
              maxLines: 6,
            ),
            ElevatedButton(
              onPressed: guardando ? null : (){
                if(formulario_key.currentState!.validate()){
                  //Navigator.push(context, MaterialPageRoute(builder: (context) => Resultado(titulo: titulo_controller.text, descripcion: descripcion_controller.text)));
                  print('todo bien');
								  guardarNota();
                } else {
                  print('todo mal');
                }
              },
              child: Text(guardando ? 'Guardando' : 'Guardar'),
            ),
          ]
        )
      ),
    );
  }
}