import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class DetalleNota extends StatefulWidget {
  const DetalleNota({super.key});

  @override
  State<DetalleNota> createState() => _DetalleNotaState();
}
  

class _DetalleNotaState extends State<DetalleNota> {

  bool cargando = true;
  final supabase = Supabase.instance.client;
  var infoNota = {};

  	bool guardando = false;
	// acceder al formulario de manera global
    final formulario_key = GlobalKey<FormState>();

	// acceder a los inputs
    final titulo_controller = TextEditingController();
    final descripcion_controller = TextEditingController();



  @override
  void initState() {
	super.initState();
	// esto se ejecuta cuando entro a la pantalla
	traerDatos();
  }


  traerDatos() async {
	print('--------');
	print('trayendo datos');

	setState(() {
	  cargando = true;
	});

	try {

	  String? id = Get.parameters['id'];
	  print('-------..-----.-.-.-.-.-..-.-.-..-.-');
	  print(id);
	  if (id == null) {
	    return;
	  }

	  var info = await supabase
	  	.from('notas')
		.select()
		.eq('id', id)
		.limit(1);


	  // con esto valido que el arreglo no esté vacío
   	  if (info != []) {
   	    infoNota = info[0];
		// infoNota es lo que viene de la base de datos
		// con esto rellenamos los inputs
		titulo_controller.text = infoNota['titulo'];
		descripcion_controller.text = infoNota['descripcion'];
   	  }

	  print('----------');
	  print(infoNota);
	  setState(() {});

	} catch (e) {
		print('----------');
		print('hay un error');
		print(e);
	} finally {
		// se ejecuta al final, si da error o si funciona
		setState(() {
		  cargando = false;
		});
	}
  }


  borrarNota() async {

	try {

		String? id = Get.parameters['id'];
		print('-------..-----.-.-.-.-.-..-.-.-..-.-');
		print(id);
		if (id == null) {
			return;
		}

		await supabase.from('notas').delete().eq('id', id);

		Get.offAndToNamed('/lista');

	} catch (e) {
		Get.snackbar(
			'Error',
			'No se pudo eliminar la nota',
			backgroundColor: Colors.red,
			colorText: Colors.white
		);
	}

  }



	guardarNota() async {

		setState(() {
			guardando = true;
		});

		try {


			String? id = Get.parameters['id'];
			print('-------..-----.-.-.-.-.-..-.-.-..-.-');
			print(id);
			if (id == null) {
				return;
			}

			await supabase
				.from('notas')
				.update({
					'titulo': titulo_controller.text,
					'descripcion': descripcion_controller.text,
					'estatus': 'Pendiente'
				})
				.eq('id', id);

			Get.snackbar('Guardado'	, 'Nota guardada');
		} catch (e) {

			print(e);
			Get.snackbar(
				'Error',
				'No se pudo guardar la nota',
				backgroundColor: Colors.red,
				colorText: Colors.white
			);

		} finally {
			setState(() {
				guardando = false;
			});
		}
	}



  @override
  Widget build(BuildContext context) {
    return Scaffold(
		appBar: AppBar(title: Text('Detalle')),
		body: elegirQueRenderizar(),
	);
  }

  Widget elegirQueRenderizar() {
	if ( cargando ) {
	  return Center(
		child: CircularProgressIndicator(),
	  );
	}

	return Column(
		children: [

			Form(
				key: formulario_key,
				child: Column(
					children: [
						TextFormField(
							controller: titulo_controller,
							decoration: InputDecoration(
								hintText: 'Ingresa un título'
							),
							autovalidateMode: AutovalidateMode.onUserInteraction,
							validator: (value) {

								if (value!.isEmpty){
									return 'Completa este campo';
								}

								return null;
							},
						),
						TextFormField(
							controller: descripcion_controller,
							decoration: InputDecoration(
								hintText: 'Ingresa una descripción'
							),
							minLines: 1,
							maxLines: 6,
						),
						ElevatedButton(
							onPressed: guardando ? null : (){
								if ( formulario_key.currentState!.validate() ) {
									print('todo bn');
									guardarNota();
								} else {
									print('todo mal');
								}
							},
							child: Text(guardando ? 'Guardando' : 'Guardar'),
						)
					],
				)
			),


			IconButton(
				onPressed: (){
					confirmarEliminar();
				},
				icon: Icon( Icons.delete ),
				color: Colors.red,
			)
		],
	);


  }

	confirmarEliminar() {

		return showDialog(
			context: Get.overlayContext!,
			builder: (context) => AlertDialog(
				title: Text('Confirmar'),
				content: Text('¿Seguro de que quieres eliminar esta nota?'),
				actions: [
					TextButton(
						onPressed: () => Get.back(),
						child: Text('No')
					),
					TextButton(
						onPressed: () {
							borrarNota();
							Get.back();
						},
						child: Text('Si, eliminar')
					),
				],
			)
		);
	}

}
