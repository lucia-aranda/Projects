import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';

class Cuadros3 extends StatelessWidget {

  const Cuadros3({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo:'Cuadros', color: const Color.fromARGB(255, 171, 253, 173)),
      body: Container(
        padding: EdgeInsets.all(10),
        child: Column(
            children: [
            Expanded(
              child: Container(
                color: Colors.blue[900],
              ),
            ),
             
             Expanded(
              flex: 1,
              child: Container(
                color: Colors.blue,
                margin: EdgeInsets.symmetric(horizontal:1.0,vertical:30.0),
                child: Row(
                children: [
                  Expanded(
                    child: Container(
                      color: Colors.orange,
                      margin: EdgeInsets.symmetric(horizontal:70.0,vertical:10.0),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.orange,
                      margin: EdgeInsets.symmetric(horizontal:70.0,vertical:10.0),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.orange,
                      margin: EdgeInsets.symmetric(horizontal:70.0,vertical:10.0),
                    ),
                  ),
                ],
              ),
              ),
            ),

            Expanded(
              flex:2,
              child: Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Container(
                      color: Colors.blue,
                      margin: EdgeInsets.symmetric(horizontal:30.0,vertical:16.0),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Container(
                      color: Colors.blue,
                      margin: EdgeInsets.symmetric(horizontal:30.0,vertical:16.0),
                    ),
                  ),
                  // child:Column(
                  //   children: [ Expanded]
                  // )
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.all(10),
                      child: Column(
                        children: [
                          Expanded(child: Container(
                            margin: EdgeInsets.all(10),
                            color: Colors.orange,
                          )),
                          Expanded(child: Container(
                            margin: EdgeInsets.all(10),
                            color: Colors.orange,
                          )),
                        ],
                      )
                      
                    ),
                  ),

                ],
              ),
            //   flex: 2,
            //   child: Row(
            //     children: [
            //       Expanded(
            //         child: Container(
            //           color: Colors.blue,
            //           margin: EdgeInsets.all(8.0),
            //         ),
            //       ),
            //       Expanded(
            //         child: Container(
            //           color: Colors.blue,
            //           margin: EdgeInsets.all(8.0),
            //         ),
            //       ),
            //       Expanded(
            //         child: Container(
            //           color: Colors.orange,
            //           margin: EdgeInsets.all(8.0),
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            // Expanded(
            //   flex: 2,
            //   child: Row(
            //     children: [
            //       Expanded(
            //         child: Container(
            //           color: Colors.blue,
            //           margin: EdgeInsets.all(8.0),
            //         ),
            //       ),
            //       Expanded(
            //         child: Container(
            //           color: Colors.blue,
            //           margin: EdgeInsets.all(8.0),
            //         ),
            //       ),
            //       Expanded(
            //         child: Container(
            //           color: Colors.orange,
            //           margin: EdgeInsets.all(8.0),
            //         ),
            //       ),
            //     ],
            //   ),
             ),
            Expanded(
              child: Container(
                color: Colors.blue[900],
              ),
            ),
          ],

        )
      )
    );
  }
}