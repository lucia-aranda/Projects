import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';

class Cuadros2 extends StatelessWidget {

  const Cuadros2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo:'Cuadros', color: const Color.fromARGB(255, 163, 242, 165)),
      body: Column(
        children: [
            Expanded(
              flex: 2,
              child: Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Container(
                      color: Colors.green,
                      margin: EdgeInsets.all(10),
                    ),
                  ),
                  // child:Column(
                  //   children: [ Expanded]
                  // )
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.all(10),
                      child: Column(
                        children: [
                          Expanded(child: Container(
                            margin: EdgeInsets.all(10),
                            color: Colors.yellow,
                          )),
                          Expanded(child: Container(
                            margin: EdgeInsets.all(10),
                            color: Colors.black,
                          )),
                        ],
                      )
                      
                    ),
                  ),

                ],
              ),
            ),
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      color: Colors.blue,
                      margin: EdgeInsets.all(10),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.red,
                      margin: EdgeInsets.all(10),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                color: Colors.orange,
                margin: EdgeInsets.all(10),
              ),
            ),
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      color: Colors.red,
                      margin: EdgeInsets.all(10),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.green,
                      margin: EdgeInsets.all(10),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.blue,
                      margin: EdgeInsets.all(10),
                    ),
                  ),
                ],
              ),
            ),
          ],
      ),
    );
  }
}