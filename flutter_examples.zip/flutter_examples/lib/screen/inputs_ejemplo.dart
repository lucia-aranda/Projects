import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';
class InputsEjemplo extends StatefulWidget {
  const InputsEjemplo({super.key});

  @override
  State<InputsEjemplo> createState() => _InputsEjemploState();
}

class _InputsEjemploState extends State<InputsEjemplo> {
  bool ocultarTexto = true;
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo: "Inputs", color: Colors.teal),
      drawer: CustomDrawer(),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
        child: Column(
          children: [
            TextFormField(
              autocorrect: false,
              autofocus: true,
              cursorColor: Colors.red,
              //initialValue: 'valor por defecto',
              keyboardAppearance: Brightness.dark,
              keyboardType: TextInputType.phone,
              maxLength: 20,
              obscureText: ocultarTexto,
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Escribe tu contraseña',
                labelText: 'Contraseña',
                suffixIcon: IconButton(icon: Icon(ocultarTexto ? Icons.visibility : Icons.visibility_off), onPressed: (){
                  ocultarTexto = !ocultarTexto;
                  setState(() {});
                },)
              ),
            ),
            SizedBox(height: 20),
            TextFormField(
              minLines: 1,
              maxLines: 4,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                ),
              ),
            SizedBox(height: 20),
            TextFormField(
              decoration: InputDecoration(
                //border: OutlineInputBorder(),
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.soap)
                ),
            ),
            SizedBox(height: 20),
            TextFormField(
              textAlign: TextAlign.end,
              decoration: InputDecoration(
                suffixIcon: Icon(Icons.attach_email),
                errorStyle: TextStyle(
                  fontSize: 15,
                  color: Colors.amber,
                )
              ),
              autovalidateMode: AutovalidateMode.onUserInteraction,
              validator: (value) {
                if(value?.trim() == null || value!.trim().isEmpty){
                  return 'Por favor, escribe algo';
                }
              // if (value == null || value.isEmpty) {
              //   return 'Por favor, ingresa un correo de contacto';
              // }
              if(value.trim().length < 5){
                return "Debe ser más de 5 caracteres";
              }
              if (!value.isEmail){
                return 'Ingresa un correo válido';
              }
              return null;
              },
            ),
            SizedBox(height: 20),
          ],
        ),
        ),
    );
  }
}

