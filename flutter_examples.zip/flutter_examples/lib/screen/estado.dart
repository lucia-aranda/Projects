import 'package:flutter/material.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';

class Estado extends StatefulWidget {
  const Estado({super.key});

  @override
  State<Estado> createState() => _EstadoState();
}

class _EstadoState extends State<Estado> {
  int numero = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo: "Estado", color: Color.fromARGB(255, 39, 191, 229)),
      drawer: CustomDrawer(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Número $numero', style: TextStyle(fontSize: 30),)
            ],),),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: () {
              //numero++;
              setState((){
                numero++;
              });
              print(numero);
            },
            //tooltip: 'Increment',
            child: Icon(Icons.add),
          ),
          SizedBox(height: 20),
          FloatingActionButton(
            onPressed: () {
              //numero++;
              setState((){
                numero--;
                if(numero<0){
                  numero=0;
                  //numero--;
                  //setState(() {});
                }
              });
              print(numero);
            },
            //tooltip: 'Decrement',
            child: Icon(Icons.remove),
          ),
          SizedBox(height: 20),
          FloatingActionButton(
            onPressed: () {
              //numero++;
              setState((){
                numero=0;
              });
              print(numero);
            },
            //tooltip: 'Decrement',
            child: Icon(Icons.exposure_zero),
          ),
        ],
      ),
    );
  }
}