import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
//ctrl + . hacer documento stateful
class Perros extends StatefulWidget {
  const Perros({super.key});

  @override
  State<Perros> createState() => _PerrosState();
}

class _PerrosState extends State<Perros> {

  bool mostrar = true;
  int numero = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo: "Perros", color: Color.fromARGB(255, 97, 174, 2)),
      body: Column(
        children: [
          Visibility(
            visible: mostrar,
            child: Image.asset('../../assets/perros/perro$numero.jpg')
            ),
          //Image.asset('../../assets/perros/perro5.jpg'),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: mostrar ? null :() {
              mostrar = true;
              setState(() {});
            }, 
            child: Text('Mostrar'),
            ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: !mostrar ? null :() {
              mostrar = false;
              setState(() {});
            }, 
            child: Text('Ocultar'),
            ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed:() {
              numero = Random().nextInt(10) + 1;
              print(numero);
              setState(() {});
            }, 
            child: Text('Aleatorio'),
            ),
        ],
      ),
    );
  }
}
//boton para mostrar, ocultar y mostrar un perro aleatorio, cuando esté oculto, el boton de ocultar debe estar deshabilitado