//Deben diseñar este formulario con validaciones de campos vacíos. No es necesario agregar esos campos específicamente, pueden ser los que gusten (mínimo 3) y sobre la temática que gusten. La imagen es sólo de referencia para mostrar como se verían los mensajes de error.
import 'package:flutter/material.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';

void main() {
  runApp(AgregarProducto());
}

class AgregarProducto extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Formulario de Registro',
      home: Scaffold(
        appBar: CustomAppbar(titulo:'Agregar producto', color: Color.fromARGB(255, 230, 158, 194)),
        body: MyCustomForm(),
      ),
    );
  }
}

class MyCustomForm extends StatefulWidget {
  const MyCustomForm({Key? key}) : super(key: key);

  @override
  MyCustomFormState createState() {
    return MyCustomFormState();
  }
}

class MyCustomFormState extends State<MyCustomForm> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          TextFormField(
            decoration: InputDecoration(labelText: 'Nombre del evento'),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor, ingresa el nombre del evento';
              }
              return null;
            },
          ),
          TextFormField(
            decoration: InputDecoration(labelText: 'Ubicación'),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor, ingresa la ubicación';
              }
              return null;
            },
          ),
          TextFormField(
            decoration: InputDecoration(labelText: 'Número de asistentes'),
            keyboardType: TextInputType.number,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor, ingresa el número de asistentes';
              }
              return null;
            },
          ),
          TextFormField(
            decoration: InputDecoration(labelText: 'Correo de contacto'),
            keyboardType: TextInputType.emailAddress,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor, ingresa un correo de contacto';
              }
              return null;
            },
          ),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                // Procesar la información aquí
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Formulario válido')),
                );  
              }
            },
            child: Text('Registrar'),
          ),
        ],
      ),
    );
  }
}
