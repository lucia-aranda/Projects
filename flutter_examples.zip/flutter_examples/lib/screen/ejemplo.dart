import 'package:flutter/material.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';

class Ejemplo extends StatelessWidget {
  const Ejemplo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ejemplo'),
      ),
    drawer: CustomDrawer(),
    );
  }
}