import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:get/get.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';

//despues de statelesswidget poner cursor y ctrl punto para statefulwidget

class Lista extends StatefulWidget {
  const Lista({super.key});
  //const Lista({Key? key}) : super(key: key);

  @override
  State<Lista> createState() => _ListaState();
}

class _ListaState extends State<Lista> {

  List listaDeNotas =[];
  bool cargando = true;
  final supabase = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    traerDatos();
  }
  traerDatos() async {
    print("-----------");
    print("Trayendo datos");

  setState((){
    cargando = true;
  });

  try{
    listaDeNotas = await supabase.from('notas').select();
    print('----------------');
    print(listaDeNotas);
    setState(() {});
  } catch (e){
    print('----------------');
    print('hay un error');
    print(e);
  } finally {
    setState((){
      cargando = false;
    });
  }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo: "Lista", color: Color.fromARGB(255, 71, 138, 21)),
      drawer: CustomDrawer(),
      body: elegirQueRenderizar(),
    );
  }
  Widget elegirQueRenderizar() {
    if (cargando) {
      return Center(
        child: CircularProgressIndicator(),
      );
    }

    if (listaDeNotas.length == 0) {
      return Center(child: Text('No hay notas'));
    } else {
      return lista();
    }
  }

  Widget lista() {
    return ListView.separated(
        separatorBuilder: (context, index) => Divider(),
        itemCount: listaDeNotas.length,
        itemBuilder: (context, index) {
          final nota = listaDeNotas[index];
          return ListTile(
            title: Text(nota['titulo']), //?? ''
            subtitle: Text(nota['descripcion']),
            onTap: () {
              Get.toNamed('/detallenota/' + nota['id'].toString());
            },
          );
        });
  }
  }