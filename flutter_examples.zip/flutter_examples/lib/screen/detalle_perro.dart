import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
//import 'package:flutter_application_1/constants/imagenes.dart';

class DetallePerro extends StatelessWidget {
  const DetallePerro({super.key});

  @override
  Widget build(BuildContext context) {
    //https://medium.com/@muhammadrahman2042/routing-in-getx-841e5cebed5a

     Map<String, dynamic> arguments = Get.arguments ?? {};
    String ruta_imagen = arguments['ruta_imagen'] ?? '';
    String nombre = arguments['nombre'] ?? '';
    
    return Scaffold(appBar: CustomAppbar
    (titulo: nombre, color: Color.fromARGB(255, 138, 152, 229)),
    body: Column(
      children: [
         Hero(tag: ruta_imagen, child: Image.asset(ruta_imagen),),
      ],
    ));
  }
}