import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';

class Cuadros extends StatelessWidget {

  const Cuadros({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo:'Cuadros', color: const Color.fromARGB(255, 163, 245, 166)),
      body: Container(
        padding: EdgeInsets.all(10),
        child: Column(
            children: [
              Expanded(
                flex: 2,
                child: Container(
                // width: double.infinity,
                // height: 100,
                margin: EdgeInsets.all(10),
                color: Colors.blue,
                ),
              ),

              Expanded(
                child: Container(
                // width: double.infinity,
                // height: 100,
                margin: EdgeInsets.all(10),
                child: Row(
                  children:[

                    Expanded(
                      child: Container(
                        margin: EdgeInsets.all(10),
                        color: Colors.purple,
                      ),
                    ),

                    Expanded(
                      child: Container(
                        margin: EdgeInsets.all(10),
                        color: Colors.purple,
                      ),
                    ),

                    Expanded(
                      child: Container(
                        margin: EdgeInsets.all(10),
                        color: Colors.purple,
                      ),
                    ),

                  ]
                )
                ),
              ),

              Expanded(
                child: Container(
                // width: double.infinity,
                // height: 100,
                margin: EdgeInsets.all(10),
                color: Colors.yellow,
                ),
              ),

              Expanded(
                child: Container(
                // width: double.infinity,
                // height: 100,
                margin: EdgeInsets.all(10),
                color: Colors.yellow,
                ),
              ),

              Expanded(
                child: Container(
                // width: double.infinity,
                // height: 100,
                margin: EdgeInsets.all(10),
                color: Colors.yellow,
                ),
              ),

            ],
        )
      )
    );
  }
}

// import 'package:flutter/material.dart';

// void main() {
//   runApp(Plantilla());
// }

// class Plantilla extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Expanded Layout',
//       home: Scaffold(
//         appBar: AppBar(
//               title: const Text('Expanded'),
//               centerTitle: false,
//               backgroundColor: Color.fromARGB(255, 97, 193, 234),
//               elevation: 50.0,
//         ),
//         body: Column(
//           children: [
//             Expanded(
//               flex: 1,
//               child: Container(
//                 color: Color.fromARGB(255, 97, 177, 243),
//                 margin: EdgeInsets.all(16.0),
//               ),
//             ),
//             Expanded(
//               child: Row(
//                 children: [
//                   Expanded(
//                     child: Container(
//                       color: const Color.fromARGB(255, 214, 155, 225),
//                       margin: EdgeInsets.symmetric(horizontal:16.0,vertical:45.0),
//                     ),
//                   ),
//                   Expanded(
//                     child: Container(
//                       color: const Color.fromARGB(255, 211, 154, 222),
//                       margin: EdgeInsets.symmetric(horizontal:16.0,vertical:45.0),
//                     ),
//                   ),
//                   Expanded(
//                     child: Container(
//                       color: Color.fromARGB(255, 219, 162, 229),
//                       margin: EdgeInsets.symmetric(horizontal:16.0,vertical:45.0),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             Expanded(
//               child: Column(
//                 children: [
//                   Expanded(
//                     child: Container(
//                       color: const Color.fromARGB(255, 211, 206, 162),
//                       margin: EdgeInsets.symmetric(horizontal:16.0,vertical:8.0),
//                     ),
//                   ),
//                   Expanded(
//                     child: Container(
//                       color: const Color.fromARGB(255, 213, 208, 156),
//                       margin: EdgeInsets.symmetric(horizontal:16.0,vertical:8.0),
//                     ),
//                   ),
//                   Expanded(
//                     child: Container(
//                       color: const Color.fromARGB(255, 219, 213, 157),
//                       margin: EdgeInsets.symmetric(horizontal:16.0,vertical:8.0),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }