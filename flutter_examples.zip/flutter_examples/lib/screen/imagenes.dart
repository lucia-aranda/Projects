import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';
//import 'package:flutter_application_1/screen/detalle_perro.dart';

class Imagenes extends StatelessWidget {
  const Imagenes({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo: 'Imagenes', color: Color.fromARGB(255, 255, 254, 174)),
      drawer: CustomDrawer(),
      body: SingleChildScrollView(
        child:Column(
          children: [
            imagenesHorizontales(),
            galeriaImagenes(),
            tarjeta('../../assets/perros/perro1.jpg', 'Firulais'),
            tarjeta('../../assets/perros/perro2.jpg', 'Sushi'),
            tarjeta('../../assets/perros/perro3.jpg', 'Lola'),
            tarjeta('../../assets/perros/perro4.jpg', 'Boby'),
            tarjeta('../../assets/perros/perro5.jpg', 'Marcelo'),
            tarjeta('../../assets/perros/perro6.jpg', 'Flor'),
            tarjeta('../../assets/perros/perro7.jpg', 'Ricardo'),
            tarjeta('../../assets/perros/perro8.jpg', 'Peso'),
            tarjeta('../../assets/perros/perro9.jpg', 'Kris'),
            tarjeta('../../assets/perros/perro10.jpg', 'Nodo'),
            // Image.asset ('../../assets/perros/perro1.jpg'),
            // Image.asset ('../../assets/perros/perro2.jpg'),
            // Image.asset ('../../assets/perros/perro3.jpg'),
            // Image.asset ('../../assets/perros/perro4.jpg'),
            // Image.asset ('../../assets/perros/perro5.jpg'),
            // Image.asset ('../../assets/perros/perro6.jpg'),
            // Image.asset ('../../assets/perros/perro7.jpg'),
            // Image.asset ('../../assets/perros/perro8.jpg'),
            // Image.asset ('../../assets/perros/perro9.jpg'),
            // Image.asset ('../../assets/perros/perro10.jpg'),

            // Expanded(
            //   child: Container(
            //     child: Image.asset ('../../assets/perros/perro1.jpg'),
            //   )
            // ),

            // Expanded(
            //   child: Container(
            //     child: Image.asset ('../../assets/perros/perro2.jpg'),
            //   )
            // ),

            // Expanded(
            //   child: Container(
            //     child: Image.asset ('../../assets/perros/perro3.jpg'),
            //   )
            // ),

            // Expanded(
            //   child: Container(
            //     child: Image.asset ('../../assets/perros/perro4.jpg'),
            //   )
            // ),

            // Expanded(
            //   child: Container(
            //     child: Image.asset ('../../assets/perros/perro5.jpg'),
            //   )
            // ),

            // Expanded(
            //   child: Container(
            //     child: Image.asset ('../../assets/perros/perro6.jpg'),
            //   )
            // ),

          ],
        ),
      ),
    );
  }

  Widget tarjeta(String ruta_imagen, String nombre){
    return GestureDetector(
      onTap:(){
        print('Hola');
        print(nombre);
        //cambiar de pantalla
        Get.toNamed('/detalle_perro', arguments: {
          'ruta_imagen': ruta_imagen,
          'nombre': nombre,
        });
      },
      child: Column(
        children: [
          Hero(tag: ruta_imagen, child: Image.asset(ruta_imagen),),
          Text(nombre, style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),),
      
        ],
      ),
    );
  }

  Widget galeriaImagenes(){
    //wrap
    return Wrap(
      //'galeriaImagenes'
      spacing: 10,
      runSpacing: 20,
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro1.jpg'),
          radius: 80,
        ),
        CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro2.jpg'),
          radius: 80,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro3.jpg'),
          radius: 80,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro4.jpg'),
          radius: 80,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro5.jpg'),
          radius: 80,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro6.jpg'),
          radius: 80,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro7.jpg'),
          radius: 80,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro8.jpg'),
          radius: 80,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro9.jpg'),
          radius: 80,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro10.jpg'),
          radius: 80,
        ),
      ],
      );
  }

  Widget imagenesHorizontales(){
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
    child: Row(
      children: [
        CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro1.jpg'),
          radius: 50,
        ),
        CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro2.jpg'),
          radius: 50,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro3.jpg'),
          radius: 50,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro4.jpg'),
          radius: 50,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro5.jpg'),
          radius: 50,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro6.jpg'),
          radius: 50,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro7.jpg'),
          radius: 50,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro8.jpg'),
          radius: 50,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro9.jpg'),
          radius: 50,
        ),
         CircleAvatar(
          backgroundImage: AssetImage('../../assets/perros/perro10.jpg'),
          radius: 50,
        ),
      ],
    ));
  }
  
}