import 'package:flutter/material.dart';
//import 'package:get/get.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';

class Plantilla extends StatelessWidget {
  const Plantilla({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: CustomAppbar(titulo:'plantilla', color: Color.fromARGB(255, 219, 158, 230)),
      drawer: CustomDrawer(),
      floatingActionButton: Stack(
        children: [
          FloatingActionButton(
            onPressed: () {
              // Acción que quieres realizar al presionar el botón flotante 1
            },
            child: Icon(Icons.add),
            backgroundColor: Color.fromARGB(255, 118, 100, 233), // Color de fondo del botón flotante 1
          ),
          // Positioned(
          //   bottom: 16,
          //   right: 16,
          //   child: FloatingActionButton(
          //     onPressed: () {
          //       // Acción que quieres realizar al presionar el botón flotante 2
          //     },
          //     child: Icon(Icons.add),
          //     backgroundColor: Color.fromARGB(255, 158, 13, 225), // Color de fondo del botón flotante 2
          //     splashColor: Color.fromARGB(255, 117, 58, 227),
          //   ),
          // ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Color.fromARGB(255, 204, 143, 230),
        items:[
          BottomNavigationBarItem(icon: Icon(Icons.home),label:'home'),
          BottomNavigationBarItem(icon: Icon(Icons.search),label:'search'),
        ]
      )
    );
  }
}