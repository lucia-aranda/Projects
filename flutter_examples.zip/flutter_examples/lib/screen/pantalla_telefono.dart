import 'package:flutter/material.dart';
import 'package:flutter_application_1/constants/custom_appbar.dart';
import 'package:flutter_application_1/constants/custom_drawer.dart';

class PantallaTelefono extends StatelessWidget {
  const PantallaTelefono({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(titulo: "Teléfono", color: Colors.orange),
      drawer: CustomDrawer(),
      body: Center(
        child: Text("Pantalla Telefono"),
      )
    );
  }
}
