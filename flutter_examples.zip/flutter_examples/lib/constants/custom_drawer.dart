//stless comando para generar plantilla
import 'package:flutter/material.dart';
import 'package:get/get.dart';
//import 'package:flutter_application_1/screen/ejemplo.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});
  @override
  Widget build(BuildContext context) {
    return Drawer(
        backgroundColor: Color.fromARGB(255, 213, 165, 225),
        width: 200,
        child: SafeArea(
          child: ListView(
            children: [DrawerHeader(child: Icon(Icons.rocket)),
            ListTile(leading: Icon(Icons.email),title:Text('e m a i l'),subtitle:Text('click on it.'),onTap:(){
              Get.toNamed('/ejemplo.dart');
              //Get.to(Ejemplo());
              },),
            ListTile(trailing: Icon(Icons.phone),title:Text('p h o n e'),onTap:(){},),
            ListTile(trailing: Icon(Icons.square),title:Text('c u a d r o s  1'),onTap:(){
              Get.toNamed('/cuadros.dart');
            },),
            ListTile(trailing: Icon(Icons.square),title:Text('c u a d r o s  2'),onTap:(){
              Get.toNamed('/cuadros2.dart');
            },),
            ListTile(trailing: Icon(Icons.square),title:Text('c u a d r o s  3'),onTap:(){
              Get.toNamed('/cuadros3.dart');
            },),
            ListTile(trailing: Icon(Icons.square),title:Text('c u a d r o s  4'),onTap:(){
              Get.toNamed('/cuadros4.dart');
            },),
            ListTile(trailing: Icon(Icons.image),title:Text('i m a g e n e s'),onTap:(){
              Get.toNamed('/imagenes.dart');
            },),
              ListTile(trailing: Icon(Icons.phone_android),title:Text('c p'),onTap:(){
              Get.toNamed('/pantalla_telefono');
            },),
            ListTile(trailing: Icon(Icons.tablet),title:Text('t b'),onTap:(){
              Get.toNamed('/pantalla_tablet');
            },),
            ListTile(trailing: Icon(Icons.computer),title:Text('p c'),onTap:(){
              Get.toNamed('/pantalla_escritorio');
            },),
            ListTile(trailing: Icon(Icons.nordic_walking_rounded),title:Text('l a y o u t'),onTap:(){
              Get.toNamed('/responsive_layout');
            },),
            ListTile(trailing: Icon(Icons.radio_button_on),title:Text('b t n'),onTap:(){
              Get.toNamed('/botones');
            },),
            ListTile(trailing: Icon(Icons.move_down),title:Text('r p s'),onTap:(){
              Get.toNamed('/responsivo');
            },),
            // ListTile(trailing: Icon(Icons.apple),title:Text('a d d'),onTap:(){
            //   Get.toNamed('/agregar_producto');
            // },),
            ListTile(trailing: Icon(Icons.text_fields),title:Text('i n p u t'),onTap:(){
              Get.toNamed('/inputs_ejemplo');
            },),
             ListTile(trailing: Icon(Icons.image),title:Text('s t a t e'),onTap:(){
              Get.toNamed('/estado');
            },),
            ListTile(trailing: Icon(Icons.pets),title:Text('d o g'),onTap:(){
              Get.toNamed('/perros');
            },),
            ListTile(trailing: Icon(Icons.list),title:Text('l i s t'),onTap:(){
              Get.toNamed('/lista');
            },),
            ListTile(trailing: Icon(Icons.checklist),title:Text('f o r m'),onTap:(){
              Get.toNamed('/formulario');
            },),
            Spacer(),
            Divider(color:Colors.purple),
            ListTile(trailing: Icon(Icons.login_rounded),title:Text('e x i t'),onTap:(){},)],
          ),
        ),
      );
    // return const Placeholder();
  }
}