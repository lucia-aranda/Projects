import 'package:flutter/material.dart';
//import 'package:get/get.dart';

class CustomAppbar extends StatelessWidget implements PreferredSizeWidget { //implements PreferredSizeWidget

  //const CustomAppbar({super.key});

    final String titulo;
    final Color color;

    const CustomAppbar({
      super.key,
      required this.titulo,
      required this.color,
    });

  @override
  
  Widget build(BuildContext context) {

    return AppBar(
        title: Text(titulo), //titulo
        centerTitle: true,
        backgroundColor: color,
        elevation: 50.0,
        //shadowColor: Color.fromARGB(255, 183, 5, 237),
        actions: <Widget>[
          IconButton(
            onPressed: () {
              // Aquí va la función que quieres que se ejecute al presionar el botón
            },
            icon: Icon(
              Icons.cloud,
            ), // Aquí he cambiado icon.call() por Icon(Icons.call)
          ),
        ],
    );
  }
  
  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}