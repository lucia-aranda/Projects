import 'package:flutter/material.dart' show BuildContext, StatelessWidget, Widget, runApp;
import 'package:flutter/material.dart';
//import 'package:flutter_application_1/screen/agregar_producto.dart';
import 'package:flutter_application_1/screen/botones.dart';
import 'package:flutter_application_1/screen/detallenota.dart';
import 'package:flutter_application_1/screen/estado.dart';
import 'package:flutter_application_1/screen/formulario.dart';
//import 'package:flutter_application_1/constants/custom_drawer.dart';
import 'package:flutter_application_1/screen/imagenes.dart';
import 'package:flutter_application_1/screen/inputs_ejemplo.dart';
import 'package:flutter_application_1/screen/pantalla_escritorio.dart';
import 'package:flutter_application_1/screen/pantalla_tablet.dart';
import 'package:flutter_application_1/screen/pantalla_telefono.dart';
import 'package:flutter_application_1/screen/perros.dart';
//MaterialApp
import 'package:flutter_application_1/screen/plantilla.dart';
import 'package:flutter_application_1/screen/detalle_perro.dart';
import 'package:flutter_application_1/screen/ejemplo.dart';
import 'package:flutter_application_1/screen/cuadros.dart';
import 'package:flutter_application_1/screen/cuadros2.dart';
import 'package:flutter_application_1/screen/cuadros3.dart';
import 'package:flutter_application_1/screen/cuadros4.dart';
import 'package:flutter_application_1/layouts/responsive_layout.dart';
import 'package:flutter_application_1/screen/responsivo.dart';
import 'package:flutter_application_1/screen/lista.dart';
import 'package:get/get.dart' show GetMaterialApp, GetPage;

// void main(List<String> args) {
//   runApp(MyApp());
// }

import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> main() async {
  await Supabase.initialize(
    url: 'https://xmkibiswdmhfdmfimjkh.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhta2liaXN3ZG1oZmRtZmltamtoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTg3MjQzMzksImV4cCI6MjAzNDMwMDMzOX0.4dGrhNcf2FKvcIxUcFgeFtH83AH7tmL6EtbYzj8pHuk',
  );
  runApp(MyApp());
}
        
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter',
      home: Plantilla(), //primera pantalla al correr el codigo
      initialRoute: '/',
      getPages: [
        
        GetPage(name: '/', page: ()=>Plantilla()),
        //GetPage(name: '../constants/custom_drawer.dart', page: ()=>CustomDrawer()),
        GetPage(name: '/ejemplo.dart', page: ()=>Ejemplo()),
        GetPage(name: '/cuadros.dart', page: ()=>Cuadros()),
        GetPage(name: '/cuadros2.dart', page: ()=>Cuadros2()),
        GetPage(name: '/cuadros3.dart', page: ()=>Cuadros3()),
        GetPage(name: '/cuadros4.dart', page: ()=>Cuadros4()),
        GetPage(name: '/imagenes.dart', page: ()=>Imagenes()),
        GetPage(name: '/detalle_perro', page: ()=>DetallePerro()),
        GetPage(name: '/pantalla_telefono', page: ()=>PantallaTelefono()),
        GetPage(name: '/pantalla_tablet', page: ()=>PantallaTablet()),
        GetPage(name: '/botones', page: ()=>Botones()),
        GetPage(name: '/pantalla_escritorio', page: ()=>PantallaEscritorio()),
        GetPage(name: '/responsivo', page: ()=>Responsivo()),
        //GetPage(name: '/agregar_producto', page: ()=>AgregarProducto()),
        GetPage(name: '/inputs_ejemplo', page: ()=>InputsEjemplo()),
        GetPage(name: '/estado', page: ()=>Estado()),
        GetPage(name: '/perros', page: ()=>Perros()),
        GetPage(name: '/lista', page: ()=>Lista()),
        GetPage(name: '/formulario', page: ()=>Formulario()),
        GetPage(name: '/detallenota/:id', page: ()=>DetalleNota()),
        GetPage(name: '/responsive_layout', page: ()=>ResponsiveLayout(
          pantallaMovil: PantallaTelefono(),
          pantallaTablet: PantallaTablet(),
          pantallaEscritorio: PantallaEscritorio(),
        )),
      ],
      // debugShowCheckedModeBanner: false,
      // theme: ThemeData( useMaterial3: false ),
      debugShowCheckedModeBanner: false,
		  theme: ThemeData(
			  useMaterial3: false,
		  ),
    );
    
  }
}
