// dependiendo del tamaño de la pantalla, decide que mostrar

import 'package:flutter/widgets.dart';

class ResponsiveLayout extends StatelessWidget {
  final Widget pantallaMovil;
  final Widget pantallaTablet;
  final Widget pantallaEscritorio;
  
  const ResponsiveLayout({
    super.key,
    required this.pantallaMovil,
    required this.pantallaTablet,
    required this.pantallaEscritorio,
  });
  //const MyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constrains){
      if(constrains.maxWidth < 650){
        return pantallaMovil;
        //retornar pantalla movil
      }else if( constrains.maxHeight < 700){
        return pantallaTablet;
        //retornar pantalla tableta
      }else{
        return pantallaEscritorio;
        //retornar pantalla pc
      }
    });
  }
}