<div id="paypal-button"></div>
<script type="text/javascript" src="https://www.paypalobjects.com/api/checkout.js"></script>
<script type="text/javascript">
	paypal.Button.render({
		env:"sandbox",
		client:{
			sandbox:"ASrgv3t57XGX4PUvu3OQiyueRIAplFl9C_Amq5DiLsvPLhb-acDsmDZc-WuZgBJPmv9bYzRiKxn1H0aN"
		},
		payment: function(data, actions){
			return actions.payment.create({
				transactions:[{
					amount:{ 
					total: "<?=$datos["precio"]?>",
					currency: "USD"
					}

				}]
			})
		}, 
		onAuthorize: function(data, actions){
			return actions.payment.execute()
			.then(function(){
				window.location="confirmacion.php?pago="+data.paymentID+"&producto=<?=$datos['pk_producto']?>"
			})
	}

		}, "#paypal-button")
	</script>
	 
</script>

