<?php 
include("menu.php");
include("clases/Categorias.php");
$categoria=new Categorias();
$registro_categoria=$categoria->mostrar();
 ?>
<div>
<form action="funciones/insertar_productos.php" method="post" enctype="multipart/form-data">
<label>Nombre del producto:</label>
	<input name="nom_prod">
	<label>Descripción:</label>
	<input type="text" name="descripcion">
	<label>Stock inicial:</label>
	<input type="number" name="stock">
	<label>Sku:</label>
	<input name="sku">
	<label>Precio:</label>
	<input type="number" name="precio">
	<label>Costo:</label>
	<input type="number" name="costo">
	<label>Fotografía:</label>
	<input type="file" name="imagen">
	<label>Categoría:</label>
	<select name="fk_categoria">
		<option>Seleccione una categoria</option><?php
		while($item=mysqli_fetch_array($registro_categoria)){
			?>
			<option value="<?=$item['pk_categoria']?>"><?=$item["nom_cat"]?></option>
                 <?php
                    }
                  ?>
            </select>
	<input type="submit" value="Guardar">
</form>
</div>