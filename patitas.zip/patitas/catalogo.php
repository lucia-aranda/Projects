<?php 
include("menu.php");
 ?>
 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
</head>
<style type="text/css">
	.cuadro{
		border: black 4px solid;
		width: 25%;
		display: inline-block;
	}
	.cuadro img{
      width: 200px;
      height: 200px;
	}

</style>

<body>
<br><br>

	<h1 class="title">Catálogo de productos</h1><br>
	<div style="display:flex;">
		<div class="container">
					<?php 
						include ("clases/productos.php");
						$productos=new Productos();
						$resultados=$productos->mostrar();
						while ($arti=mysqli_fetch_array($resultados)) {
					?>
					<img href="productos.php?productos=<?=$arti['pk_producto']?>">
					
					<div class="card">
                    <figure>
                    <figcaption> 
                    	<a href="ver_detalle.php?productos=<?=$arti['pk_producto']?>"><img src="<?=$arti['foto']?>"></a>

						<h3><?=$arti['nombre']?></h3>
						<h3><?=$arti['descripcion']?></h3>
						<h3><?=$arti['stock']?></h3>
						<h3><?=$arti['sku']?></h3>
						<h3><?=$arti['precio']?></h3>
					</figcaption>

                    </figure>

                	</div>
                	
							<br><br>
							
				
			<?php 
				}
			?>
		</div>
		</div>
<div class="container">	
	 
</div>
</body>
</html>

