<link rel="stylesheet" type="text/css" href="css/bootstrap.css?a=0">
<body background="img/fondo4.png">
<div align="center" class="col-8" style="background: #33bfe6; border-radius: 15px; margin-left: 15%; margin-top: 15%;">
	<br><br>
	<h2>Ha ocurrido un error.<br><br></h2>
	<a href="formulario_categoria.php"><button type="button" class="btn btn-light">Volver al formulario</button></a> <a href="lista_categoria.php"><button type="button" class="btn btn-light">Volver a la lista</button></a> 
	<br><br>
</div>
</body>