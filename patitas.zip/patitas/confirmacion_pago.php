<?php
$pago=$_GET["pago"];
$idproducto=$_GET["producto"];

if ($pago!=""){
	echo "Se realizó con éxito";
}  else{ 
echo "no se pudo realizar el pago";
}
?>