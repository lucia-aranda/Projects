<?php
include("clases/procuctos.php");
$producto=new Productos();
$registro_producto=$producto->mostrar();

include("clases/usuario.php");
$usuario=new Usuario();
$registro_usuario=$usuario->mostrar();

include("clases/venta.php");
$venta=new Venta();
$registro_venta=$venta->mostrar();

include("clases/detalle.php");
$detalle=new Detalle();
$registro_detalle=$detalle->mostrar();
?>
<table border="5px">
    <tr>
      <th>Fecha</th>
        <th>Hora</th>
      <th>Usuario</th>
      <th>Producto</th>
      <th>Estatus</th>
      <th>Total</th>
      <th>Ganancia por venta</th>
    </tr>

    <?php 
   while ($fila=mysqli_fetch_array($registro_venta)){
      ?>
      <tr>
      <td><?=$fila["fecha_v"]?></td>
      <td><?=$fila["hora_v"]?></td>
      <td><?=$fila["nom_usu"]?></td>
      <td><?=$fila["nom_prod"]?></td>
      <td><?=$fila["total"]?></td>
      <?php 
   while ($fila=mysqli_fetch_array($registro_detalle)){
      ?>
      <td><?=$fila["gana"]?></td>
       <?php } ?>
      </tr>
      
      <?php
   } 
   ?>


</table>