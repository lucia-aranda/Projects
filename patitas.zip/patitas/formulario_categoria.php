<link rel="stylesheet" type="text/css" href="css/bootstrap.css?a=0">
<body background="img/fondo5.png">
	<br><br>
<div align="center" class="col-8" style="background: #33bfe6; border-radius: 15px; margin-left: 15%; margin-top: 15%;">
<form action="funciones/insertar_categorias.php" method="post">
	<br>
	<h4>Fecha</h4>
	<input name="fecha">
	<br>
	<h4>Hora</h4>
	<input name="hora">
	<br>
	<h4>Total</h4>
	<input name="total">
	<br>
	<h4>Usuario</h4>
	<input name="fk_usuario">
	<br>
	<h4>Producto</h4>
	<input name="fk_producto">


	<br><br>
	<input type="submit" value="Guardar">
	<br><br>
</form>
</div>
</body>