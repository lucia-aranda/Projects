<?php echo 
'<script>
		window.location="index2.php"
</script>'
?>