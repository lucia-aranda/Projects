<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="img/logo_p.png" rel="icon">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css?a=3">
	<link rel="stylesheet" type="text/css" href="css/estilo.css?a=19">
	<link rel="stylesheet" type="text/css" href="css/css_form.css?a=3">
	<link rel="stylesheet" href="css/cards.css?a=7">
	<link rel="stylesheet" type="text/css" href="https://necolas.github.io/normalize.css/8.0.1/normalize.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
	<script src="js/bootstrap.js"></script>
</head>
<body>
    
</body>
</html>