<?php 
include("menu.php");
include("clases/productos.php");
$producto= new Productos();
$registro_producto=$producto->mostrar();

$registro=$producto->mostrar();
$arti=mysqli_fetch_assoc($registro);

include("clases/servicios.php");
$servicio=new Servicios();
$registro_servicio=$servicio->mostrar();

$registro=$servicio->mostrar();
$arti=mysqli_fetch_assoc($registro);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/cards.css?a=1" >


</head>
<body>


<div class="container">
        
            <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                    <img src="img/p2.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Contamos con diferentes servicios</h5>
                        <p>Entre ellos paseadores, funerarias y más.</p>
                    </div> 
                    </div>
                    <div class="carousel-item">
                    <img src="img/fon.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Visita nuestra tienda</h5>
                        <p>Tenemos muchos productos.</p>
                    </div>
                    </div>
                    <div class="carousel-item">
                    <img src="img/p2.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Subscribete!</h5>
                        <p>Ingresa tu información electrónica para recibir promociónes para TI.</p>
                    </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div><br><br>
    <?php foreach ($registro_producto as $row) { ?>
            <?php 
            $foto = $row['foto'];
            $imagen = $foto;

             ?>
                <div class="card">
                    <figure>
                        <figcaption> 
                            <h4><?php echo $row['nombre']; ?></h4>
                            <p><?php echo $row['descripcion'];?></p>
                            <p>Stock: <?php echo $row['stock'];?></p>
                            <p><?php echo $row['sku']?></p>
                            <p>$<?php echo number_format($row['precio'],2,'.',',');?></p>	
                            <a href="ver_detalle.php"><img src="<?php echo $imagen; ?>"></a>
                        </figcaption>
                    </figure>
                </div>
    <?php } ?>
    <?php foreach ($registro_servicio as $row) { ?>
            <?php 
            $foto = $row['foto'];
            $imagen = "img/". $foto;

             ?>
                <div class="card">
                    <figure>
                        <figcaption> 
                            <h4><?php echo $row['nombre']; ?></h4>
                            <p><?php echo $row['descripcion'];?></p>
                            <p>Horario: <?php echo $row['horario'];?></p>
                            <p>Dirección: <?php echo $row['ubicacion']?></p>  
                            <img src="<?php echo $imagen; ?>">
                        </figcaption>
                    </figure>
                </div>
    <?php } ?>
</div><br><br>

 
</body>
</html>
