<?php 
include("menu.php");
include ("clases/productos.php");
$producto=new Productos();
$arregloDatos=$producto->mostrar();

$registro=$producto->mostrar();
$datos=mysqli_fetch_assoc($registro);
 ?>
 <!DOCTYPE html>
 <html>
 <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
 </head>
 <body>
    <center>
  <div>
    <br>
    <h1>Comprar producto:</h1>
    <br>
        <?php include("pago.php"); ?>
  </div>
  </center>
 
 </body>
 </html>