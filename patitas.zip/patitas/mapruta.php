<?php 
	include_once('clases/Ubicaciones.php');
	$ubicaciones= new Ubicaciones;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Google Maps - Rutas</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estiloa.css?a=4">
	<script src="//maps.googleapis.com/maps/api/js?key=AIzaSyBMPrV0T3Vud-5y8A-ke0gLcAYBzB_iaYk"></script>
	<script src="js/jquery.js?a=4"></script>
	<script src="js/functions.js?a=4"></script>
</head>
<body>
	<div class="cont">
		<table class="table-elements">
			<tr>
				<td>
					<input type="button" value="Obtener mi ubicacion - A" onclick="get_my_location();" class="btn">
				</td>
				<td>
					<input type="text" placeholder="Latitud" id="my_lat" class="txt" readonly>
				</td>
				<td>
					<input type="text" placeholder="Longitud" id="my_lng" class="txt" readonly>
				</td>
				<td>
					<select class="txt" onchange="draw_rute(this.value)">
						<option value="0">Dibujar ruta con &#8595;</option>
						<?=$ubicaciones->get_stores();?>
					</select>
				</td>
			</tr>
		</table>
		<div class="map" id="map"></div>
	</div>
	<script type="text/javascript">
		start_map();
	</script>
</body>
</html>	