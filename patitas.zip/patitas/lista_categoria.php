<?php 
include ("clases/categorias.php");
$categoria=new Categorias();

$arregloDatos=$categoria->mostrar();
 ?>

 <a href="formulario_categoria.php">Nueva categoría</a>

    <table border="5px">
        <tr>
            <th>Nombre</th>
        </tr>
        <?php 
        while ($fila=mysqli_fetch_array($arregloDatos)){
         ?>
         <tr>
            <td><?=$fila["nom_cat"]?></td>
            <td><a href="editar_categoria.php?pk_categoria=<?=$fila["pk_categoria"];?>">Editar</a></td>
         </tr>

         <?php
         } 
          ?>
        
    </table>
 </div>