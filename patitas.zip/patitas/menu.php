

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link href="img/logo_p.png" rel="icon">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css?a=3">
	<link rel="stylesheet" type="text/css" href="css/estilo.css?a=18">
	<link rel="stylesheet" type="text/css" href="css/css_form.css?a=2">
	<link rel="stylesheet" href="css/cards.css?a=6">
	<link rel="stylesheet" type="text/css" href="https://necolas.github.io/normalize.css/8.0.1/normalize.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
	<script src="js/bootstrap.js"></script>
  <style>
        /* Set the border color */
          
        .custom-toggler.navbar-toggler {
            border-color: #A373CA;
        }
        /* Setting the stroke to green using rgb values (0, 128, 0) */
          
        .custom-toggler .navbar-toggler-icon {
            background-image: url(
"data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(163, 115, 202, 0.8)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 8h24M4 16h24M4 24h24'/%3E%3C/svg%3E");
        }
  </style>
</head>
<body>

	<nav class="navbar navbar-light bg-cyan">
  		<div class="container-fluid">
        <img role="button" href="index2.php" src="img/logo_p.png" width="5%">
    		<a class="navbar-brand" href="index2.php"> Patitas</a>
        
    		<button class="navbar-toggler ml-auto custom-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      			<span class="navbar-toggler-icon"></span>
    		</button>
   			<div class="collapse navbar-collapse" id="navbarSupportedContent">
      			<ul class="navbar-nav me-auto mb-2 mb-lg-0">
        			<li class="nav-item">
          				<a class="nav-link active" aria-current="page" href="index2.php">Inicio</a>
        			</li>
					<li class="nav-item">
          				<a class="nav-link active" aria-current="page" href="catalogo_servicios.php">Servicios</a>
        			</li>
					<li class="nav-item">
          				<a class="nav-link active" aria-current="page" href="catalogo.php">Productos</a>
        			</li>
        			
        			<li class="nav-item">
          				<a class="nav-link" href="funciones/cerrar_sesion.php">Cerrar sesión</a>
        			</li>
      			</ul>
    		</div>
  		</div>
	</nav>


</body>
