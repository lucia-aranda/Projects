<!-- Esto hace que por el inicio de sesion el usuario pueda acceder a esta pagina -->
<?php
session_start();

if (!isset($_SESSION['pk_usuario'])) {
  header("location: login_patitas.php");
}
?>
<!-- aqui termina -->