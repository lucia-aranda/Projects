<?php 
class Servicios{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($fk_tip_ser,$nom_ser,$horario,$fk_usuario,$ubicacion){
		$consulta="INSERT INTO servicios (pk_servicio, fk_tip_ser, nom_ser, horario,fk_usuario,ubicacion) VALUES (null, '{$fk_tip_ser}','{$nom_ser}','{$horario}','{$fk_usuario}','{$ubicacion}', null)";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM servicios";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_servicio){
		$consulta="SELECT * FROM servicios WHERE pk_servicio='{$pk_servicio}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_servicio,$fk_tip_ser,$nom_ser,$horario,$fk_usuario,$ubicacion){
		$consulta="UPDATE servicios SET fk_tip_ser='{$fk_tip_ser}', nom_ser = '{$nom_ser}', horario='{$horario}',fk_usuario='{$fk_usuario}', ubicacion='{$ubicacion}' WHERE pk_servicio='{$pk_servicio}'";
	}
}
?>