<?php 
class Roles{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($tipo){
		$consulta="INSERT INTO roles (pk_rol, tipo) VALUES (null, '{$tipo}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM roles";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_rol){
		$consulta="SELECT * FROM roles WHERE pk_rol ='{$pk_rol}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_rol,$tipo){
		$consulta="UPDATE roles SET tipo='{$tipo}' WHERE pk_rol='{$pk_rol}'";
	}
}
?>