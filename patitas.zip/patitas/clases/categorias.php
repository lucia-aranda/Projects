<?php 
class Categorias{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($nom_cat){
		$consulta="INSERT INTO categorias (pk_categoria, nom_cat) VALUES (null, '{$nom_cat}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM categorias";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_categoria){
		$consulta="SELECT * FROM categorias WHERE pk_categoria='{$pk_categoria}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_categoria,$nom_cat){
		$consulta="UPDATE categorias SET nombre='{$nom_cat}' WHERE pk_categoria='{$pk_categoria}'";
	}
}
?>