<?php 
class Telefonos{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($dato,$estatus){
		$consulta="INSERT INTO telefonos (pk_telefono, dato,estatus) VALUES (null, '{$dato}',1)";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM telefonos WHERE estatus=1";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_telefono){
		$consulta="SELECT * FROM telefonos WHERE pk_telefono='{$pk_telefono}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_telefono,$dato){
		$consulta="UPDATE telefonos SET dato='{$dato}' WHERE pk_telefono='{$pk_telefono}'";
	}
	function baja($pk_telefono){
		$consulta="UPDATE telefonos SET estatus=0 WHERE pk_telefono='{$pk_telefono}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
}
?>