<?php 
class Documentacion{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($ruta_doc, $fk_tipo_documentacion,$estatus){
		$consulta="INSERT INTO documentacion (pk_documentacion, ruta_doc,fk_tipo_documentacion,estatus) VALUES (null, '{$ruta_doc}','{$fk_tipo_documentacion}',1)";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM documentacion WHERE estatus=1";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_documentacion){
		$consulta="SELECT * FROM documentacion WHERE pk_documentacion='{$pk_documentacion}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_documentacion,$ruta_doc,$fk_tipo_documentacion,$estatus){
		$consulta="UPDATE documentacion SET ruta_doc='{$ruta_doc}',fk_tipo_documentacion='{$fk_tipo_documentacion}' WHERE pk_documentacion='{$pk_documentacion}'";
	}
	function baja($pk_documentacion){
		$consulta="UPDATE documentacion SET estatus=0 WHERE pk_documentacion='{$pk_documentacion}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
}
?>