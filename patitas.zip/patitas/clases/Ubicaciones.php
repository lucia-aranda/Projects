<?php
	include_once('conex.php');
	class ubicaciones extends Model{

		public function __construct(){ 
     	 	parent::__construct(); 
    	}
	    public function get_lat_lng($value){
	    	$sql = $this->db->query("SELECT ubi_lat, ubi_lon FROM ubicaciones WHERE pk_ubicaciones = '$value' LIMIT 1");
	    	$lat = 0; 
	    	$lng = 0; 
	    	foreach ($sql as $key){
	    		$lat = $key['ubi_lat'];
	    		$lng = $key['ubi_lon'];
	    	}	
	    	$array = array('lat' => $lat, 'lng' => $lng);
	    	return $array;
	    }
	    public function get_stores(){
	    	$sql = $this->db->query("SELECT pk_ubicaciones, ubi_nombre FROM ubicaciones ORDER BY ubicacion_registro");
	    	$option = '';
	    	foreach ($sql as $key){
	    		$pk = $key['pk_ubicaciones'];
	    		$name = $key['ubi_nombre'];
	    		$option .= '<option value="'.$pk.'">'.$name.' - B</option>';
	    	}
	    	return $option;
	    }
	}
	if(isset($_POST['value'])){
		$class = new Ubicaciones;
		$run = $class->get_lat_lng($_POST['value']);
		exit(json_encode($run));
	}
?>