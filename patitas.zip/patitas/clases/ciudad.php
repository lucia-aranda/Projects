<?php 
class Ciudad{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($nom_ciudad,$fk_estado){
		$consulta="INSERT INTO ciudad (pk_ciudad, nom_ciudad, fk_estado) VALUES (null, '{$nom_ciudad}', '{$fk_estado}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM ciudad";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_ciudad){
		$consulta="SELECT * FROM ciudad WHERE pk_ciudad='{$pk_ciudad}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_ciudad,$nom_ciudad,$fk_estado){
		$consulta="UPDATE ciudad SET nom_ciudad='{$nom_ciudad}', fk_estado='{$fk_estado}' WHERE pk_ciudad='{$pk_ciudad}'";
	}
}
?>