<?php 
class Estados{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($nom_est){
		$consulta="INSERT INTO estados (pk_estado, nom_est) VALUES (null, '{$nom_est}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM estados";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_estado){
		$consulta="SELECT * FROM estados WHERE pk_estado ='{$pk_estado}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_estado,$nom_est){
		$consulta="UPDATE estados SET nom_est='{$nom_est}' WHERE pk_estado='{$pk_estado}'";
	}
}
?>