<?php 
class Domicilio{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($calle,$numero,$cp,$fk_ciudad){
		$consulta="INSERT INTO domicilio (pk_domicilio, calle, numero, cp, fk_ciudad) VALUES (null, '{$calle}', '{$cp}','{$numero}','{$cp}','{$fk_ciudad}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM domicilio";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_domicilio){
		$consulta="SELECT * FROM domicilio WHERE pk_domicilio='{$pk_domicilio}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_domicilio,$calle,$numero,$cp,$fk_ciudad){
		$consulta="UPDATE domicilio SET calle='{$calle}', numero = '{$numero}', cp='{$calle}' , fk_ciudad='{$fk_ciudad}' WHERE pk_domicilio='{$pk_domicilio}'";
	}
}
?>