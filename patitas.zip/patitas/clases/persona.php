<?php 
class Persona{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($nombres,$apellidos,$fk_estado){
		$consulta="INSERT INTO persona (pk_persona, nombres, apellidos, fk_estado) VALUES (null, '{$nombres}','{$apellidos}','{$fk_estado}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM persona p INNER JOIN estados e ON e.pk_estado=p.fk_estado";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_persona){
		$consulta="SELECT * FROM persona WHERE pk_persona='{$pk_persona}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_persona,$nombres,$apellidos,$fk_estado){
		$consulta="UPDATE persona SET nombres='{$nombres}', apellidos = '{$apellidos}', fk_estado='{$fk_estado}' WHERE pk_persona='{$pk_persona}'";
	}
}
?>