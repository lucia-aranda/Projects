<?php 
class Actualizacion_documentacion{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($ruta_doc_anterior,$fecha,$tiempo,$fk_doc_original){
		$consulta="INSERT INTO actualizacion_documentacion (pk_act_doc, ruta_doc_anterior, fecha,tiempo, fk_doc_original) VALUES (null, '{$ruta_doc_anterior}','{$fecha}','{$tiempo}','{$fk_doc_original}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM actualizacion_documentacion ad INNER JOIN documentacion d ON d.pk_documentacion=ad.fk_doc_original";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_act_doc){
		$consulta="SELECT * FROM actualizacion_documentacion WHERE pk_act_doc='{$pk_act_doc}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_act_doc,$ruta_doc_anterior,$fecha,$fk_doc_original){
		$consulta="UPDATE actualizacion_documentacion SET ruta_doc_anterior='{$ruta_doc_anterior}', fecha = '{$fecha}', tiempo='{$tiempo}' fk_doc_original='{$fk_doc_original}' WHERE pk_act_doc='{$pk_act_doc}'";
	}
}
?>