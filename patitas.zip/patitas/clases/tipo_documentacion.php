<?php 
class Tipo_documentacion{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($nom_tip_doc){
		$consulta="INSERT INTO tipo_documentacion (pk_tip_doc, nom_tip_doc) VALUES (null, '{$nom_tip_doc}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM tipo_documentacion";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_tip_doc){
		$consulta="SELECT * FROM tipo_documentacion WHERE pk_tip_doc ='{$pk_tip_doc}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_tip_doc,$nom_tip_doc){
		$consulta="UPDATE tipo_documentacion SET nom_tip_doc='{$nom_tip_doc}' WHERE pk_tip_doc='{$pk_tip_doc}'";
	}
}
?>