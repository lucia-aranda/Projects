<?php 
class Reseña{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($contenido,$calificacion,$fecha_r,$hora,$fk_servicio,$fk_usuario){
		$consulta="INSERT INTO reseña (pk_reseña, contenido, calificacion, fecha_r,hora,fk_servicio,fk_usuario) VALUES (null, '{$contenido}','{$calificacion}','{$fecha_r}','{$hora}','{$fk_servicio}','{$fk_usuario}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM reseña r INNER JOIN servicios s ON s.pk_servicio=r.fk_servicio INNER JOIN usuario u ON u.pk_usuario=r.fk_usuario";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_reseña){
		$consulta="SELECT * FROM reseña WHERE pk_reseña='{$pk_reseña}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_reseña,$contenido,$calificacion,$fecha_r,$hora,$fk_servicio,$fk_usuario){
		$consulta="UPDATE reseña SET contenido='{$contenido}', calificacion = '{$calificacion}', fecha_r='{$fecha_r}',hora='{$hora}', fk_servicio='{$fk_servicio}',fk_usuario='{$fk_usuario}' WHERE pk_reseña='{$pk_reseña}'";
	}
}
?>