<?php 
class Tipo_servicio{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($dato){
		$consulta="INSERT INTO tipo_servicio (pk_tipo_servicio, dato) VALUES (null, '{$dato}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM tipo_servicio";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_tipo_servicio){
		$consulta="SELECT * FROM tipo_servicio WHERE pk_tipo_servicio='{$pk_tipo_servicio}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_tipo_servicio,$dato){
		$consulta="UPDATE tipo_servicio SET dato='{$dato}' WHERE pk_tipo_servicio='{$pk_tipo_servicio}'";
	}
}
?>