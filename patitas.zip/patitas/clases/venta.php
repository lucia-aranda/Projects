<?php 
class Venta
{
	
	function __construct()
	{
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}


	function insertar($fecha,$hora,$total,$fk_usuario,$fk_producto,$estatus){
		$consulta="INSERT INTO venta (pk_venta,fecha,hora,total,fk_usuario,fk_producto,estatus) VALUES (null, '{$fecha_v}','{$hora_v}','{$total}','{$fk_usuario}','{$fk_producto}',1)";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}
	function mostrar(){
		$consulta="SELECT * FROM venta v INNER JOIN usuario u ON u.pk_usuario=v.fk_usuario INNER JOIN productos p ON p.pk_producto=v.fk_producto";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}


	function mostrarP(){
		$consulta="SELECT * FROM venta WHERE estatus=1";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarE(){
		$consulta="SELECT * FROM venta WHERE estatus=2";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarN(){
		$consulta="SELECT * FROM venta WHERE estatus=3";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizarE($pk_venta,$estatus){
		$consulta="UPDATE venta SET estatus='{$estatus}' WHERE venta.pk_venta='{$pk_venta}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}

	function mostrarPorId($pk_venta){
		$consulta="SELECT * FROM venta WHERE pk_venta='{$pk_venta}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_venta,$fecha_v,$hora_v,$total,$fk_usuario,$fk_producto){
		$consulta="UPDATE venta SET fecha_v='{$fecha}',hora_v='{$hora}',total='{$total}',fk_usuario='{$fk_usuario}',fk_producto='{$fk_producto}', estatus_ult='{$estatus_ult}' WHERE pk_venta='{$pk_venta}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function baja($pk_venta){
		$consulta="UPDATE venta SET estatus=0 WHERE pk_venta='{$pk_venta}'";
		$resultado=$this->conexion->query($consulta);		
		return $resultado;
	}
}
 ?>