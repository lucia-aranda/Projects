<?php 
class Productos
{
	
	function __construct()
	{
		require_once("clases/Conexion.php");
		$this->conexion = new Conexion();
	}


	function insertar($nombre,$descripcion,$stock,$sku,$precio,$foto){
		$consulta="INSERT INTO productos (pk_producto,nombre,descripcion,stock,sku,estatus,precio,foto) VALUES (null, '{$nombre}','{$descripcion}','{$stock}','{$sku}',1,'{$precio}','{$foto}')";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}
	function mostrar(){
		$consulta="SELECT * FROM productos";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_producto){
		$consulta="SELECT * FROM productos WHERE pk_producto='{$pk_producto}'";
		$respuesta=$this->conexion->query($consulta); 
		return $respuesta;
	}
	function actualizar($pk_producto,$nom_prod,$descripcion,$stock,$sku,$estatus,$precio,$foto){
		$consulta="UPDATE productos SET nom_prod='{$nom_prod}',descripcion='{$descripcion}',stock='{$stock}',sku='{$sku}',precio='{$precio}',costo='{$costo}',foto='{$foto}',fk_categoria='{$fk_categoria}' WHERE pk_producto='{$pk_producto}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function baja($pk_producto){
		$consulta="UPDATE productos SET estatus=0 WHERE pk_producto='{$pk_producto}'";
		$resultado=$this->conexion->query($consulta);		
		return $resultado;
	}
}
 ?>