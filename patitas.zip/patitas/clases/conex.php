<?php 
	class Model{
		protected $db;
		public function __construct(){
			$this->db = new mysqli("localhost", "root","", "patitas");
			if($this->db->connect_errno){
				exit();
			}
			$this->db->set_charset("utf8");
		}
	}
?>