<?php 
class Servicio_doc{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($fk_servicio,$fk_documentacion){
		$consulta="INSERT INTO servicio_doc (pk_serv_doc, fk_servicio, fk_documentacion) VALUES (null, '{$fk_servicio}','{$fk_documentacion}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM servicio_doc sd INNER JOIN servicios s ON s.pk_servicio=sd.fk_servicio INNER JOIN documentacion d ON d.pk_documentacion=sd.fk_documentacion";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_serv_doc){
		$consulta="SELECT * FROM servicio_doc WHERE pk_serv_doc='{$pk_serv_doc}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_serv_doc,$fk_servicio,$fk_documentacion){
		$consulta="UPDATE servicio_doc SET fk_servicio='{$fk_servicio}', fk_documentacion = '{$fk_documentacion}' WHERE pk_serv_doc='{$pk_serv_doc}'";
	}
}
?>