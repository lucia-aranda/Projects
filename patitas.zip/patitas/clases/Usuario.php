<?php 
class Usuario
{
	
	function __construct()
	{
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}


	function insertar($nom_usu,$perfil,$email,$pwd){
		$consulta="INSERT INTO usuario (pk_usuario,nom_usu,perfil,email,pwd,tipo,estatus) VALUES (null,'{$nom_usu}','{$perfil}','{$email}','{$pwd}',1,1)";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}
	function buscar($nom_usu,$email,$pwd){
		$consulta="SELECT * FROM usuario WHERE nom_usu='{$nom_usu}' and email='{$email}' AND pwd='{$pwd}' AND estatus=1";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}

	function mostrar(){
		$consulta="SELECT * FROM usuario WHERE estatus=1";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}
	
	
	function cambiar_admin($pk_usuario){
		$consulta="UPDATE usuario SET tipo=1 WHERE pk_usuario='{$pk_usuario}'";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}
	function cambiar_normal($pk_usuario){
		$consulta="UPDATE usuario SET tipo=2 WHERE pk_usuario='{$pk_usuario}'";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}
	function mostrar_baja(){
		$consulta="SELECT * FROM usuario WHERE estatus=0";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}
	function cambiar_activo($pk_usuario){
		$consulta="UPDATE usuario SET estatus=1 WHERE pk_usuario='{$pk_usuario}'";
		$resultado=$this->conexion->query($consulta);
		return $resultado;
	}
	
	function baja($pk_usuario){
		$consulta="UPDATE usuario SET estatus=0 WHERE pk_usuario='{$pk_usuario}'";
		$resultado=$this->conexion->query($consulta);		
		return $resultado;
	}
}
 ?>