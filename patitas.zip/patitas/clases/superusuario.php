<?php 
class Superusuario{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($fk_usuario){
		$consulta="INSERT INTO superusuario (pk_sup_usu, fk_usuario) VALUES (null, '{$fk_usuario}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM superusuario s INNER JOIN usuario u ON u.pk_usuario=s.fk_usuario";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrar(){
		$consulta="SELECT * FROM superusuario";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_sup_usu){
		$consulta="SELECT * FROM superusuario WHERE pk_sup_usu='{$pk_sup_usu}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_sup_usu,$fk_usuario){
		$consulta="UPDATE superusuario SET fk_usuario='{$fk_usuario}' WHERE pk_sup_usu='{$pk_sup_usu}'";
	}
}
?>