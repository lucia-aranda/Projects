<?php 
class Detalle{
	
	function __construct(){
		require_once("Conexion.php");
		$this->conexion = new Conexion();
	}
	function insertar($gana){
		$consulta="INSERT INTO detalle (pk_detalle, gana, fk_estado) VALUES (null, '{$gana}')";
		$resultado=$this->conexion->query($consulta); //esto indica de donde se obtiene la info
		return $this->conexion->insert_id; //esta funcion regresa el resultado
	}
	function mostrar(){
		$consulta="SELECT * FROM detalle";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function mostrarPorId($pk_detalle){
		$consulta="SELECT * FROM detalle WHERE pk_detalle='{$pk_detalle}'";
		$resultado=$this->conexion->query($consulta); 
		return $resultado;
	}
	function actualizar($pk_detalle,$gana,$fk_estado){
		$consulta="UPDATE detalle SET gana='{$gana}' WHERE pk_detalle='{$pk_detalle}'";
	}
}
?>