<?php 
include("../clases/categorias.php");
$categorias=new Categorias();

$nom_cat=$_POST["nom_cat"];

$respuesta=$categorias->insertar($nom_cat);

if ($respuesta==true) {
	echo "<meta http-equiv='REFRESH' content='0; url=../confirmacion_categoria.php'>";
}else{
	echo "<meta http-equiv='REFRESH' content='0; url=../error_categoria.php'>";
}

 ?>