<?php
session_start();
include("../clases/Usuario.php");

$usuario=new Usuario();

$nom_usu=$_POST['nom_usu'];
$email=$_POST['email'];
$pwd=$_POST['pwd'];

$resultado=$usuario->buscar($nom_usu ,$email, $pwd);
$resultado2=mysqli_num_rows($resultado);
$datos=mysqli_fetch_assoc($resultado);

if ($resultado2==0) {
	echo "<meta http-equiv='REFRESH' content='0; url=../formulario_inicio_sesion.php'> <script> alert('Usuario o contraseña incorrectos') </script>";
	echo "<meta http-equiv='REFRESH' content='0; url=../login_patitas.php'> <script> alert('Introdusca sus datos de nuevo') </script>";
}else{
	$_SESSION["pk_usuario"]=$datos["pk_usuario"];
	$_SESSION["nom_usu"]=$nom_usu;
	$_SESSION["email"]=$email;
	$_SESSION["pwd"]=$datos["pwd"];

	echo "<meta http-equiv='REFRESH' content='0;
	url=../index2.php'> <script> alert('Bienvenido(a)') </script>";
}

?>