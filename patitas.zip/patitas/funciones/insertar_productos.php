<?php 
include("../clases/productos.php");
$productos=new Productos();

$nom_prod=$_POST["nom_prod"];
$descripcion=$_POST["descripcion"];
$stock=$_POST["stock"];
$sku=$_POST["sku"];
$precio=$_POST["precio"];
$costo=$_POST["costo"];
$fk_categoria=$_POST["fk_categoria"];

$archi_nombre=$_FILES["imagen"]["tmp_name"];
$nombre_foto=$_FILES["imagen"]["name"];

move_uploaded_file($archi_nombre,"../img/".$nombre_foto);

$respuesta=$productos->insertar($nom_prod,$descripcion,$stock,$sku,$precio,$costo,$nombre_foto,$fk_categoria);

if ($respuesta==true) {
	echo "Guardado";
}else{
	echo "Error";
}

 ?>