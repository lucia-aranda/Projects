<?php 
include("clases/categorias.php");
$categoria=new Categorias();
$pk_categoria=$_GET["pk_categoria"];
$registro=$categoria->mostrarPorId($pk_categoria);
$datos=mysqli_fetch_assoc($registro);
 ?>

 <form action="funciones/actualizar_categorias.php" enctype="multipart/form-data" method="post">
   <input type="hidden" name="pk_categoria" value="<?=$pk_categoria?>">
   <label>Nombre actual:</label>
   <input value="<?=$datos['nom_cat']?>" type="text" name="nom_cat">
   <input type="submit" value="Actualizar">
</form>