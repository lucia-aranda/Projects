<?php
include("clases/procuctos.php");
$producto=new Productos();
$registro_producto=$producto->mostrar();

include("clases/detalle.php");
$detalle=new Detalle();
$registro_detalle=$detalle->mostrar();
?>
<table border="5px">
    <tr>
      <th>Opciones</th>
        <th>SKU</th>
      <th>Nombre</th>
      <th>Stock</th>
      <th>Estatus</th>
      <th>Ganancia por unidad</th>
    </tr>

    <?php 
   while ($fila=mysqli_fetch_array($registro_producto)){
      ?>
      <tr>
         <td><a href="editar_producto.php?pk_producto=<?=$fila["pk_producto"];?>">Editar</a>/<a href="funciones/baja_productos.php?pk_producto=<?=$fila["pk_producto"];?>">Eliminar</a></td>

      <td><?=$fila["sku"]?></td>
      <td><?=$fila["nom_prod"]?></td>
      <td><?=$fila["stock"]?></td>
      <td><?=$fila["estatus"]?></td>
      <?php 
   while ($fila=mysqli_fetch_array($registro_detalle)){
      ?>
      <td>$<?=$fila["gana"]?></td>
      <?php
   } 
   ?>
      </tr>
      
      <?php
   } 
   ?>


</table>