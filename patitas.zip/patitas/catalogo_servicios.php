<?php 
include("menu.php");
include("clases/servicios.php");
$servicio=new Servicios();
$registro_servicio=$servicio->mostrar();

$registro=$servicio->mostrar();
$arti=mysqli_fetch_assoc($registro);

?>
<h1 class="title">Catálogo de servicios</h1>
<div class="container">
    <?php foreach ($registro_servicio as $row) { ?>
            <?php 
            $foto = $row['foto'];
            $imagen = "img/". $foto;

             ?>
                <div class="card">
                    <figure>
                        <figcaption> 
                            <h4><?php echo $row['nombre']; ?></h4>
                            <p><?php echo $row['descripcion'];?></p>
                            <p>Horario: <?php echo $row['horario'];?></p>
                            <p>Dirección: <?php echo $row['ubicacion']?></p>  
                            <img src="<?php echo $imagen; ?>">
                        </figcaption>
                    </figure>
                </div>
    <?php } ?>
    <?php include("mapruta.php"); ?>

    <div style="display:table;">
        <br><br>
    <h4>Huellitas</h4>
    <a href="https://www.google.com/maps/dir//Avenida+Luis+Donaldo+Colosio+%231001+locales+7+y+8,+Huertos+Familiares,+82137+Mazatlán,+Sin./@23.2506872,-106.4693821,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x869f53d4dcf06e53:0x4dc540f786342126!2m2!1d-106.3993417!2d23.2507027"><img src="img/maphuell.jpg"></a>
    <br><br>
    <h4>Spa</h4>
    <a href="https://www.google.com/maps/dir//calle+coronel+medina+%23819,+Coronel+Medina%23+819,+Pueblo+Nuevo,+82120+Mazatlán,+Sin./@23.2448975,-106.4978485,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x869f534320c92611:0x2e6bcf93a18e2517!2m2!1d-106.4277876!2d23.244919"><img src="img/mapspa.jpg"></a>
    <br><br>
    </div>
</div>
