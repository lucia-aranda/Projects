package com.android.pregunta_random;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private Button btn_niños, btn_fiesta;
    private ImageView btn_agregar_niños, btn_agregar_fiesta;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        btn_niños =findViewById(R.id.btn_niños);
        btn_fiesta =findViewById(R.id.btn_fiesta);
        btn_agregar_niños = findViewById(R.id.btn_agregar_niños);
        btn_agregar_fiesta = findViewById(R.id.btn_agregar_fiesta);

        btn_niños.setOnClickListener(view ->{
            Bundle enviarDatos = new Bundle();
            enviarDatos.putString("pk_categoria","1");

            Intent intent = new Intent(MainActivity.this, actividad_listado_categorias.class);
            intent.putExtras(enviarDatos);
            startActivity(intent);
        });

        btn_fiesta.setOnClickListener(view->{
            Bundle enviarDatos = new Bundle();
            enviarDatos.putString("pk_categoria","2");

            Intent intent = new Intent(MainActivity.this, actividad_listado_categorias.class);
            intent.putExtras(enviarDatos);
            startActivity(intent);

        });

        btn_agregar_niños.setOnClickListener( view->{
            Bundle enviarDatos = new Bundle();
            enviarDatos.putString("pk_categoria","1");

            Intent intent = new Intent(MainActivity.this, registrar_preguntas.class);
            intent.putExtras( enviarDatos );
            startActivity( intent );
        });

        btn_agregar_fiesta.setOnClickListener( view->{
            Bundle enviarDatos = new Bundle();
            enviarDatos.putString("pk_categoria","2");

            Intent intent = new Intent(MainActivity.this, registrar_preguntas.class);
            intent.putExtras( enviarDatos );
            startActivity( intent );
        });
    }
}