package com.android.divisas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText cantidad_ingresada;
    private Button btn_calcular;

    private TextView dol;
    private TextView rb;
    private TextView eur;
    private TextView le;

    private double precio_dol = 20.08;
    private double precio_rb = 0.26;
    private double precio_eur = 19.50;
    private double precio_le = 1.02;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cantidad_ingresada = findViewById(R.id.cantidad_ingresada);
        btn_calcular = findViewById(R.id.btn_calcular);

        dol = findViewById(R.id.dol);
        rb = findViewById(R.id.rb);
        eur = findViewById(R.id.eur);
        le = findViewById(R.id.le);

        btn_calcular.setOnClickListener( view -> {
            String cantidad_inicial = cantidad_ingresada.getText().toString();

            if (cantidad_inicial.equals("")){
                return;
            }

            int cantidad = Integer.parseInt(cantidad_inicial);

            double res_dol = cantidad * precio_dol;
            double res_rb = cantidad * precio_rb;
            double res_eur = cantidad * precio_eur;
            double res_le = cantidad * precio_le;

            dol.setText(String.format("$%s", res_dol));
            rb.setText(String.format("$%s", res_rb));
            eur.setText(String.format("$%s", res_eur));
            le.setText(String.format("$%s", res_le));
        });

    }

    public void setBtn_calcular(Button btn_calcular) {
        this.btn_calcular = btn_calcular;
    }
}