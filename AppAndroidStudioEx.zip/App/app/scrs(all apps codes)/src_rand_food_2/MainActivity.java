package com.android.random_food;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> lista_de_cosas;
    private ArrayAdapter<String> listaAdapter;
    private ListView listView;
    private Button btn_agregar, btn_elegir;
    private EditText et_input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.lv_lista);
        btn_agregar = findViewById(R.id.btn_agregar);
        btn_elegir = findViewById(R.id.btn_aleatorio);
        et_input = findViewById(R.id.et_texto);

        btn_agregar.setOnClickListener(view -> {
            String texto_escrito = et_input.getText().toString();
            if(texto_escrito.equals("")){
                Toast.makeText(this, "Debes escribir algo", Toast.LENGTH_SHORT).show();
            }else{
                listaAdapter.add(texto_escrito);
                et_input.setText("");
            }
        });

        lista_de_cosas = new ArrayList<>();
        listaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista_de_cosas);
        listView.setAdapter(listaAdapter);

        btn_elegir.setOnClickListener(view -> {
            int indice = (int) (Math.random()*lista_de_cosas.size());
            String elegido = lista_de_cosas.get(indice);
            Toast.makeText(this, "El elegido es: "+elegido, Toast.LENGTH_SHORT).show();
        });

        borrar_items();
    }

    private void borrar_items(){
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                lista_de_cosas.remove(i);
                listaAdapter.notifyDataSetChanged();
                Toast.makeText(getApplicationContext(), "Eliminado", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

    }
}