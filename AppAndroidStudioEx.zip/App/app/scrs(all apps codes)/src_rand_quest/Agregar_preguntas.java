package com.example.randomquest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Agregar_preguntas extends AppCompatActivity {

    EditText et_pregunta;
    String texto_pregunta;
    String URL;
    String pk_categoria;
    Button btn_registrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_preguntas);

        et_pregunta = findViewById( R.id.et_pregunta );
        btn_registrar = findViewById( R.id.btn_registrar );
        //-------------------
        Bundle recibirDatos = getIntent().getExtras();
        String pk_categoria = recibirDatos.getString("pk_categoria");

        btn_registrar.setOnClickListener(view -> {

            texto_pregunta = et_pregunta.getText().toString();
            if (texto_pregunta.length() > 0 ){
                System.out.println("aaa");
                System.out.println(texto_pregunta);
                guardarPregunta(texto_pregunta,pk_categoria);
            }
        });
    }
    private void guardarPregunta( String texto_pregunta, String pk_categoria) {
        URL = "http://192.168.1.69/api_preguntas/guardar_preguntas.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                System.out.println("----------");
                System.out.println("----------");
                System.out.println("----------");
                System.out.println("----------");
                System.out.println("----------");
                System.out.println("----------");
                System.out.println(response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String mensaje = jsonObject.getString("mensaje");

                    if (mensaje.equals("guardado")) {
                        Toast.makeText(getApplicationContext(), "Pregunta registrada.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Error al registrar tu pregunta.", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    System.out.println("----------");
                    System.out.println("----------");
                    System.out.println("----------");
                    System.out.println("----------");
                    System.out.println(e.toString());
                    Toast.makeText(getApplicationContext(), "Hay un error en el servidor", Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("----------");
                System.out.println("----------");
                System.out.println("----------");
                System.out.println("----------");
                System.out.println(error.toString());
                Toast.makeText(getApplicationContext(), "Pregunta registrada", Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<>();
                parametros.put("pregunta", texto_pregunta);
                parametros.put("categoria", pk_categoria);
                return parametros;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    }