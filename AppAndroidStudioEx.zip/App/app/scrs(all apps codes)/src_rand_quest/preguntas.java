package com.example.randomquest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class preguntas extends AppCompatActivity {

    private TextView tv_pregunta;
    private Button btn_siguiente;
    private String URL;

    private ArrayList<String> lista_de_cosas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preguntas);

        tv_pregunta = findViewById( R.id.tv_pregunta );
        btn_siguiente = findViewById( R.id.btn_siguiente );

        lista_de_cosas = new ArrayList<>();

        //recibir datos
        Bundle recibirDatos = getIntent().getExtras();
        String pk_categoria = recibirDatos.getString("pk_categoria");

        URL = "http://192.168.1.69/api_preguntas/buscar_preguntas.php?pk_categoria=" + pk_categoria;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response ){
                try{
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("preguntas");

                    for( int i = 0; i < jsonArray.length();i++){
                        JSONObject p = jsonArray.getJSONObject(i);
                        String pregunta = p.getString("pregunta");
                        lista_de_cosas.add( pregunta );
                    }
                    elegir_aleatorio();
                } catch (JSONException e ){
                    Toast.makeText(getApplicationContext(), "Error al recuperar", Toast.LENGTH_SHORT).show();
                }

            }

        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue( this );
        requestQueue.add(stringRequest);

        btn_siguiente.setOnClickListener( view -> {
            elegir_aleatorio();
        });

    }
    private void elegir_aleatorio(){
        if (lista_de_cosas.size() > 0){
            int indice = (int) (Math.random() * lista_de_cosas.size() );

            String elegido = lista_de_cosas.get( indice );
            tv_pregunta.setText(elegido);
            lista_de_cosas.remove(indice);
        } else {
            Toast.makeText(getApplicationContext(), "No hay mas preguntas", Toast.LENGTH_SHORT).show();
        }
    }
}