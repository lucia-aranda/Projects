package com.android.kittens;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int[] edad_gato = {0, 15, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92, 96};
    int posicion_act = 1;

    private Button btn1_calc, btn2_calc;
    private TextView yh, yc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1_calc = findViewById(R.id.btn1_calc);
        btn2_calc = findViewById(R.id.btn2_calc);
        yc = findViewById(R.id.yc);
        yh = findViewById(R.id.yh);

        btn2_calc.setOnClickListener(view -> {

            if (posicion_act <= 20) {
                posicion_act++;
                int edad_act = edad_gato[posicion_act - 0];

                yh.setText(edad_act + " años");

                yc.setText(posicion_act + " años");

                if(posicion_act <= 1){
                    yc.setText(posicion_act + " año");
                }


            } else {
                Toast.makeText(this, "No mas datos", Toast.LENGTH_SHORT).show();
            }
        });

        btn1_calc.setOnClickListener(view -> {

            if (posicion_act >= 20) {
                Toast.makeText(this, "No mas datos", Toast.LENGTH_SHORT).show();



            } else {
                posicion_act--;
                int edad_act = edad_gato[posicion_act - 0];

                yh.setText(edad_act + " años");
                yc.setText(posicion_act + " años");
            }
        });


    }
}