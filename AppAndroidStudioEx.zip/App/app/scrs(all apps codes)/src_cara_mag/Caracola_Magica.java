package com.example.caracolamgica;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;

public class Caracola_Magica extends AppCompatActivity {
    private EditText pregunta;
    private ImageView iv_imagen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caracola_magica);

        pregunta = findViewById(R.id.inputCaracola);
        iv_imagen = findViewById(R.id.imagen_caracola);

        pregunta.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                int longitud = charSequence.length();
                if ( longitud > 0 ) {
                    char ultimo = charSequence.charAt( longitud - 1 );
                    char interrogacion = '?';
                    if ( ultimo == interrogacion ) {
                        if ( Math.random() < 0.5 ) {
                            iv_imagen.setImageResource( R.drawable.si );
                        } else {
                            iv_imagen.setImageResource( R.drawable.no );
                        }
                    } else {
                        iv_imagen.setImageResource( R.drawable.preguntar );
                    }
                } else {
                    iv_imagen.setImageResource( R.drawable.preguntar );
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }
}