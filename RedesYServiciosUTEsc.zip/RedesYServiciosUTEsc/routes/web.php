<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Persona_controller;
use App\Http\Controllers\Telefono_controller;
use App\Http\Controllers\TipoUsuario_controller;
use App\Http\Controllers\Usuario_controller;
use App\Http\Controllers\Edificio_controller;
use App\Http\Controllers\Marca_controller;
use App\Http\Controllers\Modelo_controller;
use App\Http\Controllers\Dispositivo_controller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/login1', function () {
    return view('login');
})->name('login1');
Route::get('/index', function () {
    return view('welcome');
});
Route::get('/indexGod', function () {
    return view('inicioGod');
})->name('indexGod');

Route::get('/Edificio', function () {
    return view('agregarYVistaEdificio');
});
Route::post('/Edificio',[Edificio_controller::class,"insertar"])->name('edificio.insertar');
Route::get('/Edificio', [Edificio_controller::class, 'mostrar'])->name('edificio.mostrar');
Route::put('/edificio/{pkEdificio}', [Edificio_controller::class, 'baja'])->name('edificio.baja');
Route::get('/actualizarEdificio/{pkEdificio}', [Edificio_controller::class, 'mostrarPorId'])
    ->name('edificio.mostrarId');
    
Route::put('/actualizarEdificio/{pkEdificio}', [Edificio_controller::class, 'actualizar'])->name('edificio.actualizar');
    
Route::get('/formulario', function () {
    return view('formulario_persona');
});
Route::get('/formularioNota', function () {
    return view('formulario_nota');
});
Route::get('/registroDeUsuario', function () {
    return view('registrarUsuario');
});
Route::post('/AgregandoUsuario', [Usuario_controller::class, 'agregar'])->name('Usuario.agregar');
Route::post('/inicioSesion', [Usuario_controller::class, 'login'])->name('inicioSesion');

Route::post('/registroPersona', [Persona_controller::class,"insertar"])->name('persona.insertar');

Route::get('/listadoPersona',[Persona_controller::class,"mostrar"]);

Route::get('/marca', function () {
    return view('agregarVistaMarca');
})->name('marca');
Route::post('/marca', function () {
    return view('agregarVistaMarca');
})->name('marca');
Route::post('/marca', [Marca_controller::class, 'insertar'])->name('marca.insertar');
Route::get('/marca', [Marca_controller::class, 'mostrar'])->name('marca.mostrar');
Route::get('/bajaMarca/{pkMarca}', [Marca_controller::class, 'baja'])->name('marca.baja');
Route::put('/marca/{pkMarca}/update', [Marca_controller::class, 'editar'])->name('marca.editar');
Route::get('/marca/{pkMarca}/update', [Marca_controller::class, 'actualizado'])->name('marca.actualizado');

Route::get('/modelo', function () {
    return view('agregarVistaModelo');
})->name('agregarModelo');
Route::post('/modelo', function () {
    return view('agregarVistaModelo');
})->name('modelosRegistrados');
Route::post('/modelo', [Modelo_controller::class, 'insertar'])->name('modelo.insertar');
Route::get('/modelo', [Modelo_controller::class, 'mostrar'])->name('modelo.mostrar');
Route::get('/bajaModelo/{pkModelo}', [Modelo_controller::class, 'baja'])->name('modelo.baja');
Route::put('/modelo/{pkModelo}/update', [Modelo_controller::class, 'editar'])->name('modelo.editar');
Route::get('/modelo/{pkModelo}/update', [Modelo_controller::class, 'actualizado'])->name('modelo.actualizado');

Route::get('/Dispositivo', function () {
    return view('agregarDispositivo');
})->name('agregarDispositivo');
Route::post('/dispositivo', function () {
    return view('vistaDispositivo');
})->name('dispositivosRegistrados');
Route::post('/Dispositivo',[Dispositivo_controller::class,"insertar"])->name('dispositivo.insertar');
Route::get('/dispositivo', [Dispositivo_controller::class, 'mostrar'])->name('dispositivo.mostrar');
Route::get('/bajaDispositivo/{pkDispositivo}', [Dispositivo_controller::class, 'baja'])->name('dispositivo.baja');
Route::put('/dispositivo/{pkDispositivo}/update', [Dispositivo_controller::class, 'editar'])->name('dispositivo.editar');
Route::get('/dispositivo/{pkDispositivo}/update', [Dispositivo_controller::class, 'actualizado'])->name('dispositivo.actualizado');

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified'
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});
