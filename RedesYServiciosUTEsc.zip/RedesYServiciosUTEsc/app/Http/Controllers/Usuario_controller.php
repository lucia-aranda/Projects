<?php

namespace App\Http\Controllers;
use App\Models\Usuario;
use App\Models\Persona;
use Illuminate\Http\Request;


class Usuario_controller extends Controller
{
    public function login(Request $request)
    {
        $nombre = $request->input('nombre');
        $contraseña = $request->input('contraseña');
    
        $usuario = $this->buscar($nombre,$contraseña);
    
        if ($usuario) {
            // Establecer las variables de sesión
            session([
                'id' => $usuario->pkUsuario,
                'nombre' => $usuario->nombre,
                'contraseña' => $contraseña,
                'fkTipoUsuario' => $usuario->fkTipoUsuario
            ]);
    
            if ($usuario->fkTipoUsuario == 1) { // Redirigir al usuario con un mensaje de bienvenida
                return redirect('/indexGod')->with('success', 'Bienvenido(a) a Recursos Humanos');
            }
            if ($usuario->fkTipoUsuario == 2) {
                return redirect('/index')->with('success', 'Bienvenido(a) a Recursos Humanos');
            }
            
        } else {
            // Redirigir al usuario con un mensaje de error
            return redirect('/login1')
            ->with('error_credentials', 'Usuario o contraseña incorrectos')
            ->with('error_retry', 'Introduzca sus datos de nuevo')
            ->with('use_js_alerts', true);
        }
    }

    private function buscar($nombre, $contraseña)
    {
      
        $usuario = Usuario::where('nombre', $nombre)
            ->where('estatus', 1)
            ->first();
        if ($usuario && password_verify($contraseña,  $usuario->contraseña) ) {
            
            return $usuario;
        } else {
            return null;
        }
    }

    public function agregar(Request $req)
    {
        $persona= new Persona();
        //nombre base de datos       //nombre formulario
        $persona->nombre=$req->nombre;
        $persona->apellidoPaterno=$req->apellidoPaterno;
        $persona->apellidoMaterno=$req->apellidoMaterno;
        $persona->correo=$req->correo;
        $persona->estatus=1;

        $persona->save();
        $persona_id = $persona->pkPersona;
        $usuario = new Usuario();
        $usuario->nombre= $req->nombreUsuario;
        $usuario->contraseña= password_hash($req->contraseña , PASSWORD_DEFAULT);
        $usuario->estatus=1;
        $usuario->fkTipoUsuario=$req->tipoUsuario;
        $usuario->fkPersona=$persona_id;
        $usuario->save();
        return redirect()->route('login1');
       
    }
}
