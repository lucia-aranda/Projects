<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Red;

class Red_controller extends Controller
{
    function mostrar(Request $request) {
        $search = $request->query('search');
        $datos_red = Red::where('estatus',1)
                                ->where('nombre_red', 'LIKE', "%$search%")
                                ->paginate(10);
        return view("agregarRed", compact("datos_red"));
      }
}
