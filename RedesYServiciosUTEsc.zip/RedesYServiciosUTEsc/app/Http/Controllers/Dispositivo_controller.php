<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Dispositivo;
use App\Models\FotoDispositivo;

class Dispositivo_controller extends Controller
{
    
    function insertar(Request $req){

        $dispositivo= new Dispositivo();
        $foto= new FotoDispositivo();
                 //nombre base de datos       //nombre formulario
        $dispositivo->nombre=$req->nombre;
        $dispositivo->serie=$req->serie;
        $dispositivo->fkEdificio=$req->fkEdificio;
        $dispositivo->fkModelo=$req->fkModelo;
        $dispositivo->fkMarca=$req->fkMarca;
        $dispositivo->estatus=1;
        $dispositivo->save();
          // Manejar la carga de la imagen
    // if ($req->hasFile('fotito')) {
    //     $imagen = $req->file('fotito');
    //     $nombreImagen = $imagen->getClientOriginalName();

    //     // Guardar la imagen en la carpeta 'public/uploads' y obtener su ruta
    //     $rutaImagen = $imagen->store('public/uploads');

    //     // Obtener solo el nombre del archivo de la ruta
    //     $nombreImagenAlmacenado = basename($rutaImagen);

    //     $foto->fkDispositivo = $dispositivo->pkDispositivo;
    //     $foto->nombreFoto = $nombreImagenAlmacenado;
    //     $foto->save();
    // }
        if ($req->hasFile('fotito')) {
            $path = str_replace('/', DIRECTORY_SEPARATOR, $req->file('fotito')->store('public/unploads'));
            $foto->nombreFoto=$path;
        }
        
        if ($dispositivo->pkDispositivo) {
            return redirect('/dispositivo')->with('success', 'Guardado');
        } else {
            return redirect('/dispositivo')->with('error', 'Hay algún problema con la información');
        }
    }

    public function mostrar(){
        $datosDispositivo=Dispositivo::join('edificio', 'dispositivo.fkEdificio', '=', 'edificio.pkEdificio')
        ->join('marca', 'dispositivo.fkMarca', '=', 'marca.pkMarca')
        ->join('modelo', 'dispositivo.fkModelo', '=', 'modelo.pkModelo')
        ->select('dispositivo.*', 'edificio.estatus as edificioEstatus', 'marca.estatus as marcaEstatus', 'modelo.estatus as modeloEstatus')
        ->with('edificio', 'marca', 'modelo')
        ->where('dispositivo.estatus', '=', 1)
        ->get();
        return view('vistaDispositivo', compact('datosDispositivo'));
    }

    public function baja($pkDispositivo){
        $dato = Dispositivo::findOrFail($pkDispositivo);
        
        if ($dato) {
            $dato->estatus = 0;
            $dato->save();

            return redirect('/dispositivo')->with('success', 'Dispositivo dado de baja');
        } else {
            return redirect('/dispositivo')->with('error', 'Hay algún problema con la información');
        }
    }

    public function actualizado($pkDispositivo){
        $datosDispositivo = Dispositivo::findOrFail($pkDispositivo);
        return view('editarDispositivo', compact('datosDispositivo'));
    }

    public function editar(Request $req, $pkDispositivo){
        $datosDispositivo=Dispositivo::findOrFail($pkDispositivo);

        $datosDispositivo->nombre=$req->nombre;
        $datosDispositivo->serie=$req->serie;
        $datosDispositivo->fkEdificio=$req->fkEdificio;
        $datosDispositivo->fkModelo=$req->fkModelo;
        $datosDispositivo->fkMarca=$req->fkMarca;
        $datosDispositivo->fkDispositivo=$datosDispositivo->pkDispositivo;
        $datosDispositivo->nombreFoto=$req->fotito;
        $datosDispositivo->save();

        if ($datosDispositivo->pkDispositivo) {
            return redirect('/dispositivo')->with('success', 'Actualizado');
        } else {
            return redirect('/dispositivo')->with('error', 'Hay algún problema con la información');
        }
    }
}
