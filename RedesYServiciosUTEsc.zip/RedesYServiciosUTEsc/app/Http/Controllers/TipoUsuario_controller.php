<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TipoUsuario_controller extends Controller
{
    //
}
