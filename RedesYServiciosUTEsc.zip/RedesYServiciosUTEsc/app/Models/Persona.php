<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Persona extends Model
{
    use HasFactory;
    protected $table="persona";
    //si mi id se hubiera llamado diferente
    protected $primaryKey = 'pkPersona';
    protected $fillable=[
        'nombre',
        'apellidoPaterno',
        'apellidoMaterno',
        'estatus',
        'correo'
    ];
    //protected $primaryKey='pk_persona'
    public $timestamps=false;
}
