<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dispositivo extends Model
{
    use HasFactory;
    protected $table='dispositivo';
    protected $primaryKey='pkDispositivo';
    protected $fillable=[
        'nombre',
        'serie',
        'fkEdificio',
        'fkModelo',
        'fkMarca',
        'estatus'
    ];
    public $timestamps=false;
    public function edificio(){
        return $this->belongsTo(Edificio::class, 'fkEdificio');
    }
    public function modelo(){
        return $this->belongsTo(Modelo::class, 'fkModelo');
    }
    public function marca(){
        return $this->belongsTo(Marca::class, 'fkMarca');
    }
}
