<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
@include('header') <br> 
@include('mensaje')
    
    <h2>Agregar Red</h2>
    <form action="{{ route('red.agregar') }}" method="post">
        @csrf
        <label for="nombreRed">Nombre de la red</label>
        <input type="text" name="nombreRed" id="nombreRed" required>
        <br><br><br><br>
        <h3>Seleccioan dispositivos y puertos</h3>
        {{-- <table>
            <td><label for="usuario">Nombres:</label></td>
            <td><input type="text" id="usuario" name="nombre" required></td>
        </table> --}}
        <br><br>
        <label for="fkTipoRed">Tipo de red</label>
        <select name="fkTipoRed" required>
            <option selected value="">Seleccionar opción</option>
            @foreach ($datos_tipoRed as $dp)
                <option value="{{$dp->pkTipoRed}}">{{$dp->nombre}}</option>
            @endforeach
        </select>
    </form>

</body>
</html>