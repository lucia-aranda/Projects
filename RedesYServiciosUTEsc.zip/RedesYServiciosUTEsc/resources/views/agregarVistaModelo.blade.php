<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{-- Iconos --}}
    <link rel="stylesheet" href="{{ asset('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css') }}">
    <title>Document</title>
</head>
<body>
@include('header') <br>
@include('mensaje')
    
    <h2>Agregar Modelo</h2>
    <br><br>
    <form action="{{ route('modelo.insertar') }}" method="post">
        @csrf
        <label for="nombre">Nombre de la modelo</label>
        <input type="text" name="nombre" id="nombre" required>
        <br><br>
        <input type="submit" value="Guardar">
    </form>
    <br><br><br>

    <h2>Modelos registrados</h2>
    <br><br>
    <table id="tabla-modelo">
        <thead>
            <tr>
                <th>Nombre del modelo</th>
                <th>

                </th>
            </tr>
        </thead>
        @foreach ( $datosModelo as $dato )
            <tr>
                <td>{{ $dato->nombre }}</td>
                <td>
                    <div>
                        <div>
                            <a href="{{route('modelo.editar', $dato->pkModelo)}}">
                                <i class="bi bi-pencil-square" title="Editar datos"></i>
                            </a>
                        </div>
                        <div>
                            <a href="{{route('modelo.baja', $dato->pkModelo)}}">
                                <i class="bi bi-lock" title="Dar baja"></i>
                            </a>
                        </div>
                    </div>
                </td>
            </tr>
        @endforeach
    </table>
    <script>
        // Tabla con DataTable
        $(document).ready(function () {
            $('#tabla-modelo').DataTable({
                "language": {
                "search": "Buscar:",
                "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
                "zeroRecords": "Sin resultados",
                "lengthMenu": "Mostrar _MENU_ registros por página",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
            });
        });
    </script>
    
</body>
</html>