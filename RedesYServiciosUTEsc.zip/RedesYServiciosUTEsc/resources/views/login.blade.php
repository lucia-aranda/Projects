<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilos.css"> 
    <script src="https://kit.fontawesome.com/9064601a48.js" crossorigin="anonymous"></script>
</head>
<body class="inicio">

<form action="{{ route('inicioSesion') }}" method="post" class="login-form">
    @csrf
    <div class="contenedor_login">
        <i class="fa-solid fa-user icono-usuario" style="font-size: 50px;"></i>
    </div>
    <h2 class="bienvenido">Bienvenido de nuevo</h2>
    <label class="letras_login" for="e_mail">nombre usuario</label>
    <input class="input_isesion" type="text" name="nombre" id="nombre" placeholder="Ingrese su nombre usuario"  required>
    <label class="letras_login" for="contraseña">Contraseña</label>
    <input class="input_isesion" type="password" name="contraseña" id="contraseña"  placeholder="Ingrese su contraseña"  required>
    <input class="boton_subir" type="submit" value="Iniciar sesión">
    
</form>

</body>
</html>
