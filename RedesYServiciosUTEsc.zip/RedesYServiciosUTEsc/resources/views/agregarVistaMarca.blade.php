<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
@include('header') <br>
@include('mensaje')
    
    <h2>Agregar Marca</h2>
    <br><br>
    <form action="{{ route('marca.insertar') }}" method="post">
        @csrf
        <label for="nombre">Nombre de la marca</label>
        <input type="text" name="nombre" id="nombre" required>
        <br><br>
        <input type="submit" value="Guardar">
    </form>
    <br><br><br>

    <h2>Marcas registradas</h2>
    <br><br>
    <table id="tabla-marcas">
        <thead>
            <tr>
                <th>Nombre de la marca</th>
                <th>
                    
                </th>
            </tr>
        </thead>
        @foreach ( $datosMarca as $dato )
            <tr>
                <td>{{ $dato->nombre }}</td>
                <td>
                    <div>
                        <div>
                            <a href="{{route('marca.editar', $dato->pkMarca)}}">
                                <i class="bi bi-pencil-square" title="Editar datos"></i>
                            </a>
                        </div>
                        <div>
                            <a href="{{route('marca.baja', $dato->pkMarca)}}">
                                <i class="bi bi-lock" title="Dar baja"></i>
                            </a>
                        </div>
                    </div>
                </td>
            </tr>
        @endforeach
    </table>

    <script>
        // Tabla con DataTable
        $(document).ready(function () {
            $('#tabla-marcas').DataTable({
                "language": {
                "search": "Buscar:",
                "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
                "zeroRecords": "Sin resultados",
                "lengthMenu": "Mostrar _MENU_ registros por página",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
            });
        });
    </script>
    
</body>
</html>