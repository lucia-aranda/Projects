<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="estilos.css">
</head>
<body>


  <!-- Contenido principal de inicio -->
  <div class="content">
    <div class="breadcrumb" style="margin-left: 15px; height:30px; align-items:center;   width: 1000px;" >
      <label>Agregar Usuario</label>
    </div>
    <div class="form-container">
      <form action="{{route('Usuario.agregar')}}" method="post" enctype="multipart/form-data">
        @csrf
        <table class="form-table">
            <td><label for="usuario">Nombres:</label></td>
            <td><input type="text" id="usuario" name="nombre"  required></td>
            <td><label for="usuario">Apellido Paterno:</label></td>
            <td><input type="text" id="usuario" name="apellidoPaterno"  required></td>
            <td><label for="usuario">Apellido Materno:</label></td>
            <td><input type="text" id="usuario" name="apellidoMaterno"  required></td>
          
            
            <td><label for="">Correo</label></td>
            <td><input type="text" id="usuario" name="correo"  required></td>
            <td><label for="">Nombre Usuario</label></td>
            <td><input type="text" id="usuario" name="nombreUsuario"  required></td>
            <td><label for="">Contraseña</label></td>
            <td colspan="5"><input type="text" id="usuario" name="contraseña"  required></td>
            <td><label for="">Rol</label></td>
            <td>
              <select id="puesto-trabajo" name="tipoUsuario"  required>
                <option value="1">Admin</option>
                <option value="2">Empleado</option>
              </select>
            </td>
            </tr>
            
            <tr>
            <td colspan="6" style="text-align: center;">
              <input type="submit" value="Guardar">
              <input type="submit" value="Cancelar">
            </td>
            </tr>

        </table>
      </form>
    </div>
  </div>