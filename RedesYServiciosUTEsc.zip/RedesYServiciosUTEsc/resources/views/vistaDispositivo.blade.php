<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
@include('header') <br>
@include('mensaje')
    
    <h2>Dispositivos registrados</h2>
    <br><br>
    <table id="tabla-dispositivo">
        <thead>
            <tr>
                <th>Nombre del dispositivo</th>
                <th>Serie</th>
                <th>Edificio</th>
                <th>Modelo</th>
                <th>Marca</th>
                <th>

                </th>
            </tr>
        </thead>
        @foreach ( $datosDispositivo as $dato )
            <tr>
                <td>{{ $dato->nombre }}</td>
                <td>{{ $dato->serie }}</td>
                <td>{{ $dato->edificio->nombreEdificio }}</td>
                <td>{{ $dato->modelo->nombre }}</td>
                <td>{{ $dato->marca->nombre }}</td>
                <td>
                    <div>
                        <div>
                            <a href="{{route('dispositivo.editar', $dato->pkDispositivo)}}">
                                <i class="bi bi-pencil-square" title="Editar datos"></i>
                            </a>
                        </div>
                        <div>
                            <a href="{{route('dispositivo.baja', $dato->pkDispositivo)}}">
                                <i class="bi bi-lock" title="Dar baja"></i>
                            </a>
                        </div>
                    </div>
                </td>
            </tr>
        @endforeach
    </table>
    <script>
        // Tabla con DataTable
        $(document).ready(function () {
            $('#tabla-dispositivo').DataTable({
                "language": {
                "search": "Buscar:",
                "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
                "zeroRecords": "Sin resultados",
                "lengthMenu": "Mostrar _MENU_ registros por página",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
            });
        });
    </script>
</body>
</html>