<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Documento</title>
</head>
<body>

<br><br>
<div>
@include('header') <br>
  @include('mensaje')
    <form class="formulario123" action="{{route('edificio.insertar')}}"  method="post">
        @csrf
        <label class="labelTitulo" for="">Agregar Edificio</label>
        <div>
          <label class="ciudad123" for="">nombre edificio</label> 
            <input class="inputciudad" type="text" name="nombreEdificio" required>
            <label class="ciudad123" for="">seudonimo</label> 
            <input class="inputciudad" type="text" name="pseudonimo" required>
          <input class="agregar" type="submit" value="Agregar">
        </div>

    </form>

    <div>
    
    
<br><br>

<form action="{{ route('edificio.mostrar') }}" method="GET">
  <div class="contenedorBuscador">
    <label class="etiqueta" for="">Edificio</label>
    <input class="busqueda" type="search" name="search" value="{{ request()->query('search') }}" placeholder="Buscar por nombre">
    <input class="subir" type="submit" value="Buscar">
  </div>
</form>
<table id="tabla-edificio" class="tablaGrande">

  <thead class="tituloTabla">
    <tr>
      <th>Nombre</th>
      <th>Pseudonimo</th>
      <th>Accion</th>
    </tr>
  </thead>
  <tbody class="tablaCuerpo">
  
  @foreach($datosEdificio as $dato)
    <tr>
      <td>{{$dato->nombreEdificio}}</td>
      <td>{{$dato->pseudonimo}}</td>
      <td>
      <a href="{{ route('edificio.mostrarId',['pkEdificio' => $dato->pkEdificio]) }}">
       <button><i class="fa-solid fa-pencil"></i></button>
      </a>
     
     
      <form action="{{ route('edificio.baja', $dato->pkEdificio) }}" method="POST">
        @csrf
        <input type="hidden" name="_method" value="PUT">
        <button type="submit"><i class="bi bi-lock" title="Dar baja"></i></button>
    </form>

  </td>
    </tr>
    @endforeach
   
  </tbody>
</table>

<script>
        // Tabla con DataTable
        $(document).ready(function () {
            $('#tabla-edificio').DataTable({
                "language": {
                "search": "Buscar:",
                "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
                "zeroRecords": "Sin resultados",
                "lengthMenu": "Mostrar _MENU_ registros por página",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
            });
        });
    </script>


</body>
</html>


