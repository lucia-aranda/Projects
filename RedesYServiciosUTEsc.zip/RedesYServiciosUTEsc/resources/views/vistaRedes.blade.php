<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
    
@include('header') <br>
@include('mensaje')
<br><br>
<form action="{{ route('red.mostrar') }}" method="GET">
  <div class="contenedorBuscador">
    <label class="etiqueta" for="">Red</label>
    <input class="busqueda" type="search" name="search" value="{{ request()->query('search') }}" placeholder="Buscar por nombre">
    <input class="subir" type="submit" value="Buscar">
  </div>
</form>

<table class="tablaGrande">
  <thead class="tituloTabla">
    <tr>
      <td>Num</td>
      <td>Edificio</td>
      <td>Dispositivos</td>
      <td>Tipo</td>
      <td>Asignado a:</td>
      <td>fecha</td>
    </tr>
  </thead>
  <tbody class="tablaCuerpo">
    @foreach($datosRed as $dato)
      <tr>
        <th>{{$dato->idRed}}</th>
        <th>{{$dato->nombreEdificio}}</th>
        <th>{{$dato->nombreDispositivo}}</th>
        <th>{{$dato->nombreTipo}}</th>
        <th>{{$dato->nombreArea}}</th>
        <th>{{$dato->fecha}}</th>
      </tr>
    @endforeach
  </tbody>
</table>

 
 
</table>
<div>
          {{ $datos_Red->links() }}
   </div>

    </div>
  
</div>


</body>
</html>