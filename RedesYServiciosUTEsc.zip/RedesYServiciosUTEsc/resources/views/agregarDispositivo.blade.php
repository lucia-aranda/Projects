<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario</title>
</head>
<body>
@include('header') <br>
@include('mensaje')
    <h2>Formulario</h2>
    <form  class="formulario123" action="{{route('dispositivo.insertar')}}"  method="post">
        @csrf
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br>

        <label for="serie">Serie:</label>
        <input type="text" id="serie" name="serie" required>
        <br>
        <label for="foto">Agregar foto:</label>
        <input type="file" id="foto" name="fotito" accept="image/*" required>

        <label for="edificio">Edificio:</label>
        <select id="edificio" name="fkEdificio" required>
            @php
                use App\Models\Edificio;
                $datosEdificio = Edificio::where('estatus', '=', 1)->get();
            @endphp
            @foreach ($datosEdificio as $dato)
                <option value="{{$dato->pkEdificio}}">{{$dato->nombreEdificio}}</option>
            @endforeach
        </select>
        <br>

        <label for="marca">Marca:</label>
        <select id="marca" name="fkMarca" required>
            @php
                use App\Models\Marca;
                $datosMarca = Marca::where('estatus', '=', 1)->get();
            @endphp
            @foreach ($datosMarca as $dato)
                <option value="{{$dato->pkMarca}}">{{$dato->nombre}}</option>
            @endforeach
        </select>
        <br>

        <label for="modelo">Modelo:</label>
        <select id="modelo" name="fkModelo" required>
            @php
                use App\Models\Modelo;
                $datosModelo = Modelo::where('estatus', '=', 1)->get();
            @endphp
            @foreach ($datosModelo as $dato)
                <option value="{{$dato->pkModelo}}">{{$dato->nombre}}</option>
            @endforeach
        </select>
        <br>

        <input type="submit" value="Enviar">
    </form>
</body>
</html>
