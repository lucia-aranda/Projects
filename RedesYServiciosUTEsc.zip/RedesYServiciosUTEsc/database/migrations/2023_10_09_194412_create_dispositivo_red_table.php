<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('dispositivoRed', function (Blueprint $table) {
            $table->increments('pkDispositivoRed');
            $table->unsignedInteger('fkDispositivo');
            $table->unsignedInteger('fkRed');
            $table->unsignedInteger('fkPuerto');
            $table->timestamps();

            $table->foreign('fkDispositivo')
                ->references('pkDispositivo')
                ->on('dispositivo');

            $table->foreign('fkRed')
                ->references('pkRed')
                ->on('red');
             $table->foreign('fkPuerto')
                ->references('pkPuerto')
                ->on('puerto');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('dispositivoRed');
    }
};
