<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('puerto_dispositivo', function (Blueprint $table) {
            $table->increments('pkPuertoDispositivo');
            $table->unsignedInteger('fkPuerto');
            $table->unsignedInteger('fkDispositivo');
            $table->timestamps();

            $table->foreign('fkPuerto')
                ->references('pkPuerto')
                ->on('puerto');

            $table->foreign('fkDispositivo')
                ->references('pkDispositivo')
                ->on('dispositivo');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('puerto_dispositivo');
    }
};
